﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data.SqlClient;
using Proj.DAL;
using System.Data;

namespace DAL
{
    public class DalCommonUserOperation
    {
        /// <summary>
        /// 状态栏-查询账号当前状态
        /// </summary>
        /// <param name="id"></param>
        /// <param name="password"></param>
        /// <param name="identity"></param>
        /// <returns></returns>
        public ModelCommonUser QueryState(string id)
        {
            ModelCommonUser info = new ModelCommonUser();
            string sql = $"select state from common_user_table where id='{id}'";

            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@id",id)
            };

            SqlDataReader reader = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, System.Data.CommandType.Text, sql, par);

            while (reader.Read())
            {
                info.state = (string)reader["state"];
            }

            return info;
        }


        /// <summary>
        /// 查询和修改个人信息-获取账号注册的全部信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ModelCommonUser QueryAllInfo(string id)
        {
            ModelCommonUser info = new ModelCommonUser();
            string sql = $"select *from common_user_table where id='{id}'";

            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@id",id)
            };

            SqlDataReader reader = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, System.Data.CommandType.Text, sql, par);

            while (reader.Read())
            {
                info.password = (string)reader["password"];

                info.name = (string)reader["name"];
                info.gender = (string)reader["gender"];
                info.phone = (string)reader["phone"];
                info.QQ = (string)reader["QQ"];
                info.academy = (string)reader["academy"];

                info.major = (string)reader["major"];
                info.registration_time = (string)reader["registration_time"];

                info.borrow_book_num = (int)reader["borrow_book_num"];
                info.not_returned_book = (string)reader["not_returned_book"];
                info.note = (string)reader["note"];
            }

            return info;

        }


        /// <summary>
        /// 查询和修改个人信息-修改个人信息
        /// </summary>
        /// <param name="id"></param>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public int UpDateValue(string id,string key,string value)
        {
            string sql = $"update common_user_table set {key}='{value}' where id='{id}'";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@key",key),
                new SqlParameter("@value",value),
            };
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, sql, par);

            return i;
        }

   


        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="id"></param>
        /// <param name="table"></param>
        /// <param name="newPassword"></param>
        /// <returns></returns>
        public int ChangePassword(string id, string newPassword)
        {
            string sql = $"update common_user_table set password='{newPassword}' where id='{id}'";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@password",newPassword),
            };
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, sql, par);

            return i;
        }

        /// <summary>
        /// 获取全部用户数据
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ModelCommonUser QueryInfo()
        {
            ModelCommonUser info = new ModelCommonUser();
            string sql = $"select id,name,academy,borrow_book_num from common_user_table order by borrow_book_num+0 desc;";

            SqlDataReader reader = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, System.Data.CommandType.Text, sql, null);

            while (reader.Read())
            {
                info.id = (string)reader["id"];
                info.name = (string)reader["name"];
                info.academy = (string)reader["academy"];
                //info.major = (string)reader["major"];
                info.borrow_book_num = (int)reader["borrow_book_num"];
            }
            return info;

        }


        /// <summary>
        /// 推荐图书
        /// </summary>
        /// <returns></returns>
        public int IntroduceBook(ModelRecommendBooks recommend)
        {
            string sql = $"insert into recommend_books_table(book_name,book_author,link,reason,user_id,user_academy) values({recommend.book_name},{recommend.book_author},{recommend.link},{recommend.reason},{recommend.user_id},'{recommend.user_academy}')";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@name",recommend.book_name),
                new SqlParameter("@price",recommend.book_author),
                new SqlParameter("@link",recommend.link),
                new SqlParameter("@reason",recommend.reason),

                new SqlParameter("@user_id",recommend.user_id),
                new SqlParameter("@user_academy",recommend.user_academy),
            };

            int info = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, sql, par);
            return info;
        }

        public ModelBookTable FindRepeatBook(string bookName)
        {
            ModelBookTable info = new ModelBookTable();
            string sql = $"select name from book_table where name='{bookName}' ";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@name",bookName),

            };
            SqlDataReader reader = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, System.Data.CommandType.Text, sql, par);

            while (reader.Read())
            {
                info.name = (string)reader["name"];
            }

            return info;

        }


        /// <summary>
        /// 查询借的图书信息
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public ModelBookTable QueryBookInfo(string name)
        {
            string sql = $"select *from book_table where name='{name}'";
            ModelBookTable info = new ModelBookTable();

            SqlDataReader reader = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, System.Data.CommandType.Text, sql, null);

            while (reader.Read())
            {
                info.id = (string)reader["id"];
                info.name = (string)reader["name"];
                info.author = (string)reader["author"];
                info.location = (string)reader["location"];
                info.inventory = (string)reader["inventory"];
                info.borrow_num = (int)reader["borrow_num"];
            }
            return info;
        }


        /// <summary>
        /// 借书操作 
        /// 1、添加借书信息
        /// 2、修改图书的库存量
        /// 3、个人的借书数量
        /// </summary>
        /// <param name="borrowinfo"></param>
        /// <returns></returns>
        public int BorrowBook(ModelBorrowInfo borrowinfo)
        {
            int info = 0;
            //string InsertSql = $"insert into borrowinfo_table(book_name,book_id,user_name,user_id,time)values('{borrowinfo.book_name}','{borrowinfo.book_id}','{borrowinfo.user_name}','{borrowinfo.user_id}','{borrowinfo.time}')";
            string InsertSql = $"insert into borrowinfo_table(book_name,book_id,user_name,user_id,time)values({borrowinfo.book_name},{borrowinfo.book_id},'{borrowinfo.user_name}',{borrowinfo.user_id},'{borrowinfo.time}')";
            

            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@book_name",borrowinfo.book_name),
                new SqlParameter("@book_id",borrowinfo.book_id),
                new SqlParameter("@user_name",borrowinfo.user_name),
                new SqlParameter("@user_id",borrowinfo.user_id),

                new SqlParameter("@time",borrowinfo.time),
            };

            info = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, InsertSql, par);
            return info;
        }

        public int UpdateBookInventory(ModelBookTable booktable)
        {
            int info = 0;
            string UpdateSql = $"update book_table set inventory=inventory-1,borrow_num=borrow_num+1 where name='{booktable.name}'";
            SqlParameter[] par2 = new SqlParameter[]
            {
                new SqlParameter("@inventory",booktable.inventory),
            };
            info = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, UpdateSql, par2);

            return info;
        }
        public int UpdateUserBorrowInfo(string id)
        {
            string UpdateSql = $"update common_user_table set borrow_book_num = borrow_book_num+1 where id='{id}'";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@id",id),
            };
            int info= SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, UpdateSql, par);

            return info;
        }


        /// <summary>
        /// 还书操作
        /// 1、修改借书记录里面的还书时间
        /// 2、修改图书信息里面的库存量
        /// </summary>
        /// <param name="user_name"></param>
        /// <param name="book_id"></param>
        /// <returns></returns>
        public int UpdateBorrowBookInfo(string book_name,string user_id)
        {
            string Time_Now = DateTime.Now.ToString();

            string sql = $"update borrowinfo_table set return_time = '{Time_Now}' where book_name='{book_name}'and user_id='{user_id}'";

            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@book_name",book_name),
                new SqlParameter("@user_id",user_id),

            };

            int info = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, sql, par);
            return info;
        }

        public int UpdateBookTableInventory(string book_name)
        {
            string sql = $"update book_table set inventory = inventory+1  where name='{book_name}'";

            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@name",book_name),

            };

            int info = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, sql, par);
            return info;
        }
    }


}
