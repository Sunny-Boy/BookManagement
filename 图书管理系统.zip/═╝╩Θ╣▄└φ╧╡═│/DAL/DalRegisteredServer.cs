﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Proj.DAL;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class DalRegisteredServer
    {
        public int InsertRegisterInfo(ModelRegistered register)
        {
            DateTime dt = DateTime.Now;
            
            string sql = $"insert into common_user_table(id,password,name,gender,phone,QQ,academy,major,registration_time,note) values('{register.id}','{register.password}','{register.name}','{register.gender}','{register.phone}','{register.QQ}','{register.academy}','{register.major}','{register.registration_time}','{register.note}')";
            //string sql = $"insert into common_user_table(id,password,name,gender,phone,QQ,academy,major,note) values({register.id},{register.password},{register.name},{register.gender},{register.phone},{register.QQ},{register.academy},{register.major},{register.note}";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@id",register.id),
                new SqlParameter("@password",register.password),
                new SqlParameter("@name",register.name),

                new SqlParameter("@gender",register.gender),
                new SqlParameter("@phone",register.phone),
                new SqlParameter("@QQ",register.QQ),

                new SqlParameter("@academy",register.academy),
                new SqlParameter("@major",register.major),
                new SqlParameter("@registration_time",register.registration_time),
                new SqlParameter("@note",register.note),
            };

            int info = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, sql, par);
            return info;
        }

        public ModelRegistered FindDuplicate(string id)
        {
            ModelRegistered info = new ModelRegistered();
            string sql = $"select id from common_user_table where id='{id}' ";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@id",id),
                
            };
           

            SqlDataReader reader = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, System.Data.CommandType.Text, sql, par);

            while (reader.Read())
            {
                info.id = (string)reader["id"];
            }
            
            return info;
        }


    }
}
