﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Model;
using Proj.DAL;

namespace DAL
{
    public class DalLoginServer
    {
        public ModelLogin login(string id,string password, string identity)
        {
            ModelLogin info = new ModelLogin();

            string sql = $"select * from {identity} where id ='{id}'and password='{password}';";

          //  "select * from " + identity + "where stu_id ='" + stu_id + "'and password='" + password + "'"
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@id",id)
            };
            SqlDataReader reader = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, System.Data.CommandType.Text, sql, par);

            while (reader.Read())
            {
                info.id = (string)reader["id"];
                info.password = (string)reader["password"];
            }
            return info;
        }

    }
}
