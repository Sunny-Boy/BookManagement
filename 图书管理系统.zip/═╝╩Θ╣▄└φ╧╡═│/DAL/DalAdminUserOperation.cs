﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data.SqlClient;
using Proj.DAL;
using System.Data;

namespace DAL
{
    public class DalAdminUserOperation
    {
        /// <summary>
        /// 添加管理员操作
        /// </summary>
        /// <param name="admin"></param>
        /// <returns></returns>
        public int AddAdminUser( ModelAdminUserTable admin)
        {
            DateTime dt = DateTime.Now;

            string sql = $"insert into admin_user_table(id,password,name,position,phone,address,note,create_time) values('{admin.id}','{admin.password}','{admin.name}','{admin.position}','{admin.phone}','{admin.address}','{admin.note}','{admin.create_time}')";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@id",admin.id),
                new SqlParameter("@password",admin.password),
                new SqlParameter("@name",admin.name),

                new SqlParameter("@position",admin.position),
                new SqlParameter("@phone",admin.phone),
                new SqlParameter("@address",admin.address),
                new SqlParameter("@note",admin.note),
                new SqlParameter("@create_time",admin.create_time),
            };

            int info = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, sql, par);
            return info;
        }





        /// <summary>
        /// 查询当前id，在数据库中的所有信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ModelAdminUserTable FindAdminUserInfo(string id)
        {
            ModelAdminUserTable adminUser = new ModelAdminUserTable();
            string sql = $"select * from admin_user_table where id='{id}' ";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@id",id),

            };
            SqlDataReader reader = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, System.Data.CommandType.Text, sql, par);

            while (reader.Read())
            {
                adminUser.id = (string)reader["id"];
                adminUser.password = (string)reader["password"];
                adminUser.name = (string)reader["name"];
                adminUser.position = (string)reader["position"];

                adminUser.phone = (string)reader["phone"];
                adminUser.address = (string)reader["address"];
                adminUser.note = (string)reader["note"];
                adminUser.create_time = (string)reader["create_time"];
            }

            return adminUser;
        }


        /// <summary>
        /// 修改信息操作
        /// 使用说明：传入三个参数，一个是数据库列名，一个是数据库的值，一个当前用户
        /// 建议：把textBox的名字改成和数据库中的列名一样的名字
        /// </summary>
        public int ChangePersonalInfo(string key,string value,string id)
        {
            string sql = $"update admin_user_table set {key}='{value}' where id='{id}'";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@key",key),
                new SqlParameter("@value",value),
            };
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, sql, par);

            return i;
        }

        /// <summary>
        /// 修改普通用户的状态
        /// status-传入  '正常'/‘锁定’-奇偶数判断点击的次数即可
        /// </summary>
        public int ChangeCommonStatus(string id,string state)
        {
            string sql = $"update common_user_table set state='{state}' where id='{id}'";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@status",state),
            };
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, sql, par);

            return i;
        }

        /// <summary>
        /// 删除选中的当前普通用户
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int DelCommonUser(string id)
        {
            string sql = "delete from common_user_table where id=@id";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@id",id),
            };
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, sql, par);
            return i;
        }


        /// <summary>
        /// 新书入库
        /// </summary>
        public int AddNewBook(ModelBookTable bookInfo)
        {
            DateTime dt = DateTime.Now;

            string sql = $"insert into book_table(id,name,author,price,book_abstract,press,location,time,inventory,borrow_num) values('{bookInfo.id}','{bookInfo.name}','{bookInfo.author}','{bookInfo.price}','{bookInfo.book_abstract}','{bookInfo.press}','{bookInfo.location}','{bookInfo.time}','{bookInfo.inventory}','0')";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@id",bookInfo.id),
                new SqlParameter("@name",bookInfo.name),
                new SqlParameter("@author",bookInfo.author),

                new SqlParameter("@price",bookInfo.price),
                new SqlParameter("@book_abstract",bookInfo.book_abstract),
                new SqlParameter("@press",bookInfo.press),

                new SqlParameter("@location",bookInfo.location),
                new SqlParameter("@time",bookInfo.time),
                new SqlParameter("@inventory",bookInfo.inventory),
                new SqlParameter("@borrow_num",bookInfo.borrow_num),
            };

            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, sql, par);
            return i;

        }

        /// <summary>
        /// 查找是否存在相同书籍
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ModelBookTable FindBookTableInfo(string name)
        {
            ModelBookTable bookInfo = new ModelBookTable();
            string sql = $"select name,id from book_table where name ='{name}'";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@name",name),

            };
            SqlDataReader reader = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, System.Data.CommandType.Text, sql, par);

            while (reader.Read())
            {
                bookInfo.id = (string)reader["id"];
                bookInfo.name = (string)reader["name"];
            }
            return bookInfo;
        }

        /// <summary>
        /// 删除图书
        /// </summary>
        public int DelBook(string id)
        {
            string sql = "delete from book_table where id=@id";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@id",id),
            };
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, sql, par);
            return i;
        }

        /// <summary>
        /// 修改图书信息
        /// </summary>
        public int ModifyBookInfo(string key,string value,string name)
        {
            string sql = $"update book_table set {key}='{value}' where name='{name}'";
            SqlParameter[] par = new SqlParameter[]
            {
                new SqlParameter("@key",key),
                new SqlParameter("@value",value),
            };
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.Text, sql, par);

            return i;
        }




    }


}
