﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using System.Data.SqlClient;
using BLL;

namespace UI
{
    public partial class UiRegisterUser : Form
    {

        /// <summary>
        /// 注册按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonRegistered_Click(object sender, EventArgs e)
        {
            string id = this.TextId.Text;
            string password = this.TextPassword.Text;
            string name = this.TextName.Text;
            string gender = "";
            if (radioButton1.Checked) {
                gender = "男";
            }
            else if (radioButton2.Checked)
            {
                gender = "女";
            }
            string phone = this.TextPhone.Text;
            string academy = this.TextAcademy.Text;
            string major = this.TextMajor.Text;
            string note = this.TextNote.Text;
            string QQ = this.TextQQ.Text;
            if (id == String.Empty || name == String.Empty || gender == String.Empty || academy == String.Empty || major == String.Empty || note == String.Empty)
            {
                MessageBox.Show("注册信息不能为空！");
            }
            else if (QQ.Length < 5)
            {
                MessageBox.Show("请确保QQ的位数正确！");
            }
            else if (phone.Length < 11)
            {
                MessageBox.Show("请输入11位的手机号！");

            }
            else if (password.Length < 6)
            {
                MessageBox.Show("输入的密码应该在6位以上！");
            }
            else if (id.Length != 11)
            {
                MessageBox.Show("请输入11位的学号！");
            }
            else
            {
                ModelRegistered register = new ModelRegistered();
                register.id = id;
                register.password = password;
                register.name = name;
                register.gender = gender;
                register.QQ = QQ;
                register.phone = phone;
                register.academy = academy;
                register.major = major;
                register.note = note;
                register.registration_time = DateTime.Now.ToString();

                ModelRegistered registInfo = new BllRegisteredAPI().FindDuplicate(id);
                if (id==registInfo.id)
                {
                    MessageBox.Show("该用户名已经被注册，请核对后在输入！");
                }
                else
                {
                    int Info = new BllRegisteredAPI().QueryInsert(register);
                    if (Info > 0)
                    {
                        MessageBox.Show("注册成功,正在返回登陆！！");

                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("注册失败，请检测填写内容是否违规！");
                    }
                }
            }
            



            
        }

        public UiRegisterUser()
        {
            InitializeComponent();
        }

        private void UiRegisterUser_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            

        }
        

    }
}
