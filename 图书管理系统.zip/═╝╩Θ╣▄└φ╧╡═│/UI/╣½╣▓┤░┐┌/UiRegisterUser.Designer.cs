﻿namespace UI
{
    partial class UiRegisterUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UiRegisterUser));
            this.TextNote = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.TextMajor = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TextAcademy = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.TextQQ = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TextPhone = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.TextName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TextPassword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TextId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ButtonRegistered = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TextNote
            // 
            this.TextNote.Location = new System.Drawing.Point(447, 409);
            this.TextNote.Name = "TextNote";
            this.TextNote.Size = new System.Drawing.Size(222, 25);
            this.TextNote.TabIndex = 39;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label9.Location = new System.Drawing.Point(384, 412);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 15);
            this.label9.TabIndex = 38;
            this.label9.Text = "备 注：";
            // 
            // TextMajor
            // 
            this.TextMajor.Location = new System.Drawing.Point(447, 368);
            this.TextMajor.Name = "TextMajor";
            this.TextMajor.Size = new System.Drawing.Size(222, 25);
            this.TextMajor.TabIndex = 37;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(384, 371);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 15);
            this.label7.TabIndex = 36;
            this.label7.Text = "专 业：";
            // 
            // TextAcademy
            // 
            this.TextAcademy.Location = new System.Drawing.Point(447, 332);
            this.TextAcademy.Name = "TextAcademy";
            this.TextAcademy.Size = new System.Drawing.Size(222, 25);
            this.TextAcademy.TabIndex = 35;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label8.Location = new System.Drawing.Point(384, 335);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 15);
            this.label8.TabIndex = 34;
            this.label8.Text = "院 校：";
            // 
            // TextQQ
            // 
            this.TextQQ.Location = new System.Drawing.Point(447, 294);
            this.TextQQ.Name = "TextQQ";
            this.TextQQ.Size = new System.Drawing.Size(222, 25);
            this.TextQQ.TabIndex = 33;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label6.Location = new System.Drawing.Point(387, 297);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 15);
            this.label6.TabIndex = 32;
            this.label6.Text = "Q  Q：";
            // 
            // TextPhone
            // 
            this.TextPhone.Location = new System.Drawing.Point(450, 255);
            this.TextPhone.Name = "TextPhone";
            this.TextPhone.Size = new System.Drawing.Size(222, 25);
            this.TextPhone.TabIndex = 31;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(384, 258);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 15);
            this.label5.TabIndex = 30;
            this.label5.Text = "电 话：";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.radioButton2.Location = new System.Drawing.Point(561, 223);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(43, 19);
            this.radioButton2.TabIndex = 29;
            this.radioButton2.Text = "女";
            this.radioButton2.UseVisualStyleBackColor = false;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(474, 223);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(43, 19);
            this.radioButton1.TabIndex = 28;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "男";
            this.radioButton1.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(384, 223);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 15);
            this.label4.TabIndex = 27;
            this.label4.Text = "性 别：";
            // 
            // TextName
            // 
            this.TextName.Location = new System.Drawing.Point(450, 177);
            this.TextName.Name = "TextName";
            this.TextName.Size = new System.Drawing.Size(222, 25);
            this.TextName.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(384, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 15);
            this.label3.TabIndex = 25;
            this.label3.Text = "名 字：";
            // 
            // TextPassword
            // 
            this.TextPassword.Location = new System.Drawing.Point(450, 140);
            this.TextPassword.Name = "TextPassword";
            this.TextPassword.Size = new System.Drawing.Size(222, 25);
            this.TextPassword.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(384, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 15);
            this.label2.TabIndex = 23;
            this.label2.Text = "密 码：";
            // 
            // TextId
            // 
            this.TextId.Location = new System.Drawing.Point(450, 102);
            this.TextId.Name = "TextId";
            this.TextId.Size = new System.Drawing.Size(222, 25);
            this.TextId.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label1.Location = new System.Drawing.Point(384, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 15);
            this.label1.TabIndex = 21;
            this.label1.Text = "学 号：";
            // 
            // ButtonRegistered
            // 
            this.ButtonRegistered.Location = new System.Drawing.Point(390, 454);
            this.ButtonRegistered.Name = "ButtonRegistered";
            this.ButtonRegistered.Size = new System.Drawing.Size(282, 40);
            this.ButtonRegistered.TabIndex = 20;
            this.ButtonRegistered.Text = "注 册";
            this.ButtonRegistered.UseVisualStyleBackColor = true;
            this.ButtonRegistered.Click += new System.EventHandler(this.ButtonRegistered_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label10.Font = new System.Drawing.Font("华文行楷", 25F);
            this.label10.Location = new System.Drawing.Point(264, 22);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(566, 44);
            this.label10.TabIndex = 40;
            this.label10.Text = "注册一下信息，就开始读书吧";
            // 
            // UiRegisterUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1009, 616);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.TextNote);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.TextMajor);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TextAcademy);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.TextQQ);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.TextPhone);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TextName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TextPassword);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TextId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ButtonRegistered);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UiRegisterUser";
            this.Text = "图书管理系统";
            this.Load += new System.EventHandler(this.UiRegisterUser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TextNote;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TextMajor;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TextAcademy;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TextQQ;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TextPhone;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TextName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TextPassword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TextId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ButtonRegistered;
        private System.Windows.Forms.Label label10;
    }
}