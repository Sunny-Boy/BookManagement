﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using Model;


namespace UI
{
    public partial class UiLogin : Form
    {
        public UiLogin()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            //窗口加载

        }
        public static string globalUserName = "";
        public static string globaLevel = "";
        public static string globaIdentity = "";

        private void button1_Click(object sender, EventArgs e)
        {
            string id = textUsername.Text.Trim();
            string password = textPassword.Text.Trim();
            string identity = "";

            if (radioAdmin.Checked)
            {
                identity = "admin_user_table";
                globaIdentity = "admin_user_table";
                globaLevel = "管理员";
            }
            else if(radioUser.Checked)
            {
                identity = "common_user_table";
                globaIdentity = "common_user_table";
                globaLevel = "普通用户";
            }



            if (textUsername.Text == String.Empty)
            {
                MessageBox.Show("请输入账号！", "系统提示");
            }
            else if (textPassword.Text == string.Empty)
            {
                MessageBox.Show("请输入密码！", "系统提示");
            }
            else if (textUsername.Text.Length != 11)
            {
                MessageBox.Show("请输入11位的账号", "系统提示");

            }
            else if (textPassword.Text.Length<6)
            {
                MessageBox.Show("请输入6位或6位以上的正确密码！", "系统提示");
            }
            else
            {
                ModelLogin user = new BllLoginAPI().login(id, password, identity);


                if (user.password == password)
                {
                   
                    globalUserName = id;

                    if (identity == "admin_user_table")
                    {
                        UiAdminUserWindow admin = new UiAdminUserWindow();
                        
                        admin.Show();
                        this.Hide();

                    }
                    else if(identity == "common_user_table")
                    {
                        UiCommonUserWindow common = new UiCommonUserWindow();
                 
                        common.Show();
                        this.Hide();
                    }




                }
                else
                {
                    MessageBox.Show("输入的用户 "+ id + " ，账号或密码错误，请检查后重新输入", "系统提示");
                }
            }
            
        }


        private void RegisterLink_Click(object sender, EventArgs e)
        {
            UiRegisterUser register = new UiRegisterUser();
            register.ShowDialog();
        }



        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void textPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioUser_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioAdmin_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
