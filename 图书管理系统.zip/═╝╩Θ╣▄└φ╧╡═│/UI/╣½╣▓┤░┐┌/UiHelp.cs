﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using BLL;

namespace UI
{
    public partial class UiHelp : Form
    {
        public UiHelp()
        {
            InitializeComponent();
        }

        private void UiHelp_Load(object sender, EventArgs e)
        {
            if (UiLogin.globaLevel == "普通用户")
            {
                ModelCommonUser user = new BllCommonUserOperationAPI().QueryAllInfo(UiLogin.globalUserName);
                this.username.Text = user.id;
                this.state.Text = user.state;
                this.regeditTime.Text = user.registration_time;

            }
            else if(UiLogin.globaLevel == "管理员")
            {
                ModelAdminUserTable admin = new BllAdminUserOperationAPI().FindAdminUserInfo(UiLogin.globalUserName);
                this.username.Text = admin.id;
                this.state.Text = "无";
                this.regeditTime.Text = admin.create_time;
            }
        }
    }
}
