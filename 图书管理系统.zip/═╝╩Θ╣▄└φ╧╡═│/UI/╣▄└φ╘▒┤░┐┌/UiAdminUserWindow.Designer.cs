﻿namespace UI
{
    partial class UiAdminUserWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UiAdminUserWindow));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.添加用户 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.添加书籍 = new System.Windows.Forms.ToolStripButton();
            this.还书办理 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新用户注册 = new System.Windows.Forms.ToolStripMenuItem();
            this.用户信息修改ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改信息 = new System.Windows.Forms.ToolStripMenuItem();
            this.修改密码 = new System.Windows.Forms.ToolStripMenuItem();
            this.注销用户 = new System.Windows.Forms.ToolStripMenuItem();
            this.管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新书入库 = new System.Windows.Forms.ToolStripMenuItem();
            this.书籍注销 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关于软件 = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.booknameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookauthorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reasonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.useridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.useracademyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.recommendbookstableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookManagementDataSet2 = new UI.BookManagementDataSet2();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.recommend_books_tableTableAdapter = new UI.BookManagementDataSet2TableAdapters.recommend_books_tableTableAdapter();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.StatusWelcomeText = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusTimeNow = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusLevels = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.toolStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.recommendbookstableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet2)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolStrip1.BackgroundImage")));
            this.toolStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加用户,
            this.toolStripButton2,
            this.toolStripSeparator1,
            this.添加书籍,
            this.还书办理,
            this.toolStripSeparator4,
            this.toolStripButton7,
            this.toolStripButton1,
            this.toolStripSeparator3,
            this.toolStripButton6});
            this.toolStrip1.Location = new System.Drawing.Point(0, 28);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1391, 66);
            this.toolStrip1.TabIndex = 7;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // 添加用户
            // 
            this.添加用户.AutoSize = false;
            this.添加用户.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.添加用户.Image = ((System.Drawing.Image)(resources.GetObject("添加用户.Image")));
            this.添加用户.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.添加用户.Name = "添加用户";
            this.添加用户.Size = new System.Drawing.Size(49, 44);
            this.添加用户.Text = "普通用户管理";
            this.添加用户.Click += new System.EventHandler(this.添加用户_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(44, 63);
            this.toolStripButton2.Text = "个人信息修改和管理";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.AutoSize = false;
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(7, 45);
            // 
            // 添加书籍
            // 
            this.添加书籍.AutoSize = false;
            this.添加书籍.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.添加书籍.Image = ((System.Drawing.Image)(resources.GetObject("添加书籍.Image")));
            this.添加书籍.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.添加书籍.Name = "添加书籍";
            this.添加书籍.Size = new System.Drawing.Size(49, 44);
            this.添加书籍.Text = "新书入库";
            this.添加书籍.Click += new System.EventHandler(this.添加书籍_Click);
            // 
            // 还书办理
            // 
            this.还书办理.AutoSize = false;
            this.还书办理.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.还书办理.Image = ((System.Drawing.Image)(resources.GetObject("还书办理.Image")));
            this.还书办理.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.还书办理.Name = "还书办理";
            this.还书办理.Size = new System.Drawing.Size(49, 44);
            this.还书办理.Text = "图书管理";
            this.还书办理.Click += new System.EventHandler(this.还书办理_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.AutoSize = false;
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(7, 45);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.AutoSize = false;
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(49, 44);
            this.toolStripButton7.Text = "图书推荐查询";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.AutoSize = false;
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(49, 44);
            this.toolStripButton1.Text = "借书记录查询";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.AutoSize = false;
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(7, 45);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.AutoSize = false;
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(49, 44);
            this.toolStripButton6.Text = "帮助";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.系统ToolStripMenuItem,
            this.管理ToolStripMenuItem,
            this.toolStripMenuItem2,
            this.帮助ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1391, 28);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 系统ToolStripMenuItem
            // 
            this.系统ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新用户注册,
            this.用户信息修改ToolStripMenuItem,
            this.注销用户});
            this.系统ToolStripMenuItem.Name = "系统ToolStripMenuItem";
            this.系统ToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.系统ToolStripMenuItem.Text = "系统管理(S)";
            // 
            // 新用户注册
            // 
            this.新用户注册.Name = "新用户注册";
            this.新用户注册.Size = new System.Drawing.Size(174, 26);
            this.新用户注册.Text = "添加管理员";
            this.新用户注册.Click += new System.EventHandler(this.新用户注册_Click);
            // 
            // 用户信息修改ToolStripMenuItem
            // 
            this.用户信息修改ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.修改信息,
            this.修改密码});
            this.用户信息修改ToolStripMenuItem.Name = "用户信息修改ToolStripMenuItem";
            this.用户信息修改ToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.用户信息修改ToolStripMenuItem.Text = "个人信息修改";
            // 
            // 修改信息
            // 
            this.修改信息.Name = "修改信息";
            this.修改信息.Size = new System.Drawing.Size(144, 26);
            this.修改信息.Text = "修改信息";
            this.修改信息.Click += new System.EventHandler(this.修改信息_Click);
            // 
            // 修改密码
            // 
            this.修改密码.Name = "修改密码";
            this.修改密码.Size = new System.Drawing.Size(144, 26);
            this.修改密码.Text = "修改密码";
            this.修改密码.Click += new System.EventHandler(this.修改密码_Click);
            // 
            // 注销用户
            // 
            this.注销用户.Name = "注销用户";
            this.注销用户.Size = new System.Drawing.Size(174, 26);
            this.注销用户.Text = "普通用户管理";
            this.注销用户.Click += new System.EventHandler(this.注销用户_Click);
            // 
            // 管理ToolStripMenuItem
            // 
            this.管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新书入库,
            this.书籍注销});
            this.管理ToolStripMenuItem.Name = "管理ToolStripMenuItem";
            this.管理ToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.管理ToolStripMenuItem.Text = "书籍管理(B)";
            // 
            // 新书入库
            // 
            this.新书入库.Name = "新书入库";
            this.新书入库.Size = new System.Drawing.Size(144, 26);
            this.新书入库.Text = "新书入库";
            this.新书入库.Click += new System.EventHandler(this.新书入库_Click);
            // 
            // 书籍注销
            // 
            this.书籍注销.Name = "书籍注销";
            this.书籍注销.Size = new System.Drawing.Size(144, 26);
            this.书籍注销.Text = "图书管理";
            this.书籍注销.Click += new System.EventHandler(this.书籍注销_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(100, 24);
            this.toolStripMenuItem2.Text = "信息查询(P)";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(180, 26);
            this.toolStripMenuItem3.Text = "图书推荐查询";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(180, 26);
            this.toolStripMenuItem4.Text = "借书/还书查询";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // 帮助ToolStripMenuItem
            // 
            this.帮助ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.关于软件});
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(73, 24);
            this.帮助ToolStripMenuItem.Text = "帮助(H)";
            // 
            // 关于软件
            // 
            this.关于软件.Name = "关于软件";
            this.关于软件.Size = new System.Drawing.Size(181, 26);
            this.关于软件.Text = "关于软件";
            this.关于软件.Click += new System.EventHandler(this.关于软件_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.booknameDataGridViewTextBoxColumn,
            this.bookauthorDataGridViewTextBoxColumn,
            this.reasonDataGridViewTextBoxColumn,
            this.useridDataGridViewTextBoxColumn,
            this.useracademyDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.recommendbookstableBindingSource;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 21);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(732, 611);
            this.dataGridView1.TabIndex = 9;
            // 
            // booknameDataGridViewTextBoxColumn
            // 
            this.booknameDataGridViewTextBoxColumn.DataPropertyName = "book_name";
            this.booknameDataGridViewTextBoxColumn.HeaderText = "书名";
            this.booknameDataGridViewTextBoxColumn.Name = "booknameDataGridViewTextBoxColumn";
            this.booknameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bookauthorDataGridViewTextBoxColumn
            // 
            this.bookauthorDataGridViewTextBoxColumn.DataPropertyName = "book_author";
            this.bookauthorDataGridViewTextBoxColumn.HeaderText = "作者";
            this.bookauthorDataGridViewTextBoxColumn.Name = "bookauthorDataGridViewTextBoxColumn";
            this.bookauthorDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // reasonDataGridViewTextBoxColumn
            // 
            this.reasonDataGridViewTextBoxColumn.DataPropertyName = "reason";
            this.reasonDataGridViewTextBoxColumn.HeaderText = "理由";
            this.reasonDataGridViewTextBoxColumn.Name = "reasonDataGridViewTextBoxColumn";
            this.reasonDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // useridDataGridViewTextBoxColumn
            // 
            this.useridDataGridViewTextBoxColumn.DataPropertyName = "user_id";
            this.useridDataGridViewTextBoxColumn.HeaderText = "推荐人";
            this.useridDataGridViewTextBoxColumn.Name = "useridDataGridViewTextBoxColumn";
            this.useridDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // useracademyDataGridViewTextBoxColumn
            // 
            this.useracademyDataGridViewTextBoxColumn.DataPropertyName = "user_academy";
            this.useracademyDataGridViewTextBoxColumn.HeaderText = "院校";
            this.useracademyDataGridViewTextBoxColumn.Name = "useracademyDataGridViewTextBoxColumn";
            this.useracademyDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // recommendbookstableBindingSource
            // 
            this.recommendbookstableBindingSource.DataMember = "recommend_books_table";
            this.recommendbookstableBindingSource.DataSource = this.bookManagementDataSet2;
            // 
            // bookManagementDataSet2
            // 
            this.bookManagementDataSet2.DataSetName = "BookManagementDataSet2";
            this.bookManagementDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // recommend_books_tableTableAdapter
            // 
            this.recommend_books_tableTableAdapter.ClearBeforeFill = true;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StatusWelcomeText,
            this.statusTimeNow,
            this.statusLevels});
            this.statusStrip1.Location = new System.Drawing.Point(0, 735);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1391, 25);
            this.statusStrip1.TabIndex = 11;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // StatusWelcomeText
            // 
            this.StatusWelcomeText.Name = "StatusWelcomeText";
            this.StatusWelcomeText.Size = new System.Drawing.Size(458, 20);
            this.StatusWelcomeText.Spring = true;
            this.StatusWelcomeText.Text = "欢迎xxx, 进入图书管理系统";
            // 
            // statusTimeNow
            // 
            this.statusTimeNow.Name = "statusTimeNow";
            this.statusTimeNow.Size = new System.Drawing.Size(458, 20);
            this.statusTimeNow.Spring = true;
            this.statusTimeNow.Text = "当前时间：";
            // 
            // statusLevels
            // 
            this.statusLevels.Name = "statusLevels";
            this.statusLevels.Size = new System.Drawing.Size(458, 20);
            this.statusLevels.Spring = true;
            this.statusLevels.Text = "当前权限：";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Location = new System.Drawing.Point(653, 97);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(738, 635);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "学生推荐书籍";
            // 
            // UiAdminUserWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1391, 760);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UiAdminUserWindow";
            this.Text = "图书管理系统";
            this.Load += new System.EventHandler(this.UiAdminUserWindow_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.recommendbookstableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet2)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton 添加用户;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton 添加书籍;
        private System.Windows.Forms.ToolStripButton 还书办理;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新用户注册;
        private System.Windows.Forms.ToolStripMenuItem 用户信息修改ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改信息;
        private System.Windows.Forms.ToolStripMenuItem 修改密码;
        private System.Windows.Forms.ToolStripMenuItem 注销用户;
        private System.Windows.Forms.ToolStripMenuItem 管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新书入库;
        private System.Windows.Forms.ToolStripMenuItem 书籍注销;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于软件;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Timer timer;
        private BookManagementDataSet2 bookManagementDataSet2;
        private System.Windows.Forms.BindingSource recommendbookstableBindingSource;
        private BookManagementDataSet2TableAdapters.recommend_books_tableTableAdapter recommend_books_tableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn booknameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookauthorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn reasonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn useridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn useracademyDataGridViewTextBoxColumn;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel StatusWelcomeText;
        private System.Windows.Forms.ToolStripStatusLabel statusLevels;
        private System.Windows.Forms.ToolStripStatusLabel statusTimeNow;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}