﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using UI;
using UI.管理员窗口;
using UI.管理员;
using System.Data.SqlClient;

namespace UI
{
    public partial class UiAdminUserWindow : Form
    {
        public UiAdminUserWindow()
        {
            InitializeComponent();
            this.statusTimeNow.Text = "系统当前时间：" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");//在程序刚加载，就进行时间获取
        }
        

        /// <summary>
        /// 系统加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UiAdminUserWindow_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“bookManagementDataSet2.recommend_books_table”中。您可以根据需要移动或删除它。
            this.recommend_books_tableTableAdapter.Fill(this.bookManagementDataSet2.recommend_books_table);
            StatusWelcomeText.Text = "欢迎," + UiLogin.globalUserName+"进入图书管理系统";
            statusLevels.Text = "权限级别："+UiLogin.globaLevel;
            timer.Interval = 1000;
            timer.Start();



            string sql1 = $"select book_name,book_author,reason,user_id,user_academy from recommend_books_table where purchases = '未购买'";//推书推荐
            string strConn = "uid=sa;pwd=admin123;database=BookManagement;server=XTZJ-20220423MW";//SQL Server链接字符串
            SqlConnection conn = new SqlConnection(strConn);
            SqlDataAdapter sda1 = new SqlDataAdapter(sql1, conn);
            DataTable dt1 = new DataTable();//dt是一个表类型。
            sda1.Fill(dt1);//把sda读取的数据填到dt里
            dataGridView1.DataSource = dt1;//把dt的内容绑定到Gridview1里显示

        }
        /// <summary>
        /// 计时器-计时时间
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            this.statusTimeNow.Text = "系统当前时间：" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            UiAdminPersonalInfo info = new UiAdminPersonalInfo();
            info.ShowDialog();
        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void 添加用户_Click(object sender, EventArgs e)
        {
            UiAdminAddadmin addAdmin = new UiAdminAddadmin();
            addAdmin.ShowDialog();
        }

        private void 添加书籍_Click(object sender, EventArgs e)
        {
            UiAdminAddNewBook addNewBook =new UiAdminAddNewBook();
            addNewBook.ShowDialog();
        }

        private void 还书办理_Click(object sender, EventArgs e)
        {
            UiAdminBookManagement bookManagement = new UiAdminBookManagement();
            bookManagement.ShowDialog();
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            UiAdminShowBookInclude BookInclude = new UiAdminShowBookInclude();
            BookInclude.ShowDialog();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            UiAdminShowBorrowBooksRecord borrowBooksRecord = new UiAdminShowBorrowBooksRecord();
            borrowBooksRecord.ShowDialog();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            UiHelp help = new UiHelp();
            help.ShowDialog();
        }

        private void 新用户注册_Click(object sender, EventArgs e)
        {
            UiAdminAddadmin addadmin = new UiAdminAddadmin();
            addadmin.ShowDialog();
        }

        private void 修改信息_Click(object sender, EventArgs e)
        {
            UiAdminPersonalInfo info = new UiAdminPersonalInfo();
            info.ShowDialog();
        }

        private void 修改密码_Click(object sender, EventArgs e)
        {
            UiAdminChangePassword changePassword = new UiAdminChangePassword();
            changePassword.ShowDialog();
        }

        private void 注销用户_Click(object sender, EventArgs e)
        {
            UiAdminManagementUser user = new UiAdminManagementUser();
            user.ShowDialog();
        }

        private void 新书入库_Click(object sender, EventArgs e)
        {
            UiAdminAddNewBook newBook = new UiAdminAddNewBook();
            newBook.ShowDialog();
        }

        private void 书籍注销_Click(object sender, EventArgs e)
        {
            UiAdminBookManagement management = new UiAdminBookManagement();
            management.ShowDialog();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            UiAdminShowBookInclude include = new UiAdminShowBookInclude();
            include.ShowDialog();

        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            UiAdminShowBorrowBooksRecord record = new UiAdminShowBorrowBooksRecord();
            record.ShowDialog();
        }

        private void 番茄钟ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UiPomodoro pompdoro = new UiPomodoro();
            pompdoro.ShowDialog();
        }

        private void 关于软件_Click(object sender, EventArgs e)
        {
            UiHelp help = new UiHelp();
            help.ShowDialog();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
