﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using BLL;

namespace UI.管理员
{
    public partial class UiAdminAddadmin : Form
    {
        public UiAdminAddadmin()
        {
            InitializeComponent();
        }

        private void AddAdminButton_Click(object sender, EventArgs e)
        {
            string username = this.username.Text;
            string password = this.password.Text;
            string name = this.name.Text;
            string position = this.position.Text;
            string phone = this.phone.Text;
            string address = this.address.Text;
            string note = this.note.Text;


            Console.WriteLine(phone.Length);

            if (username == string.Empty && password == string.Empty && name == string.Empty && position == string.Empty && phone == string.Empty && address == string.Empty && note == string.Empty)
            {
                MessageBox.Show("注册信息不能为空！");
            }
            else if (username.Length != 11)
            {
                MessageBox.Show("请输入11位的账号！");
            }
            else if (password.Length < 6)
            {
                MessageBox.Show("密码应该在6位以上！");
            }
            else if (phone.Length!=6 && phone.Length != 11)
            {
                //(phone.Length == 11 && phone.Length != 6) || ((phone.Length != 11 && phone.Length == 6))
                MessageBox.Show("请输入正确的手机号！");

            }
            else
            {
                ModelAdminUserTable admin = new ModelAdminUserTable();
                admin.id = username;
                admin.password = password;
                admin.name = name;
                admin.position = position;
                admin.phone = phone;
                admin.address = address;
                admin.note = note;
                admin.create_time = DateTime.Now.ToString();
                ModelAdminUserTable adminInfo = new BllAdminUserOperationAPI().FindAdminUserInfo(username);
                if (admin.id == adminInfo.id)
                {
                    MessageBox.Show("当前账号已经有人注册，请检查核对！");
                }
                else
                {
                    int OP = new BllAdminUserOperationAPI().AddAdminUser(admin);
                    if (OP > 0)
                    {
                        MessageBox.Show("添加成功！");
                        
                        
                    }
                    else
                    {
                        MessageBox.Show("添加失败，请检测填写内容是否违规！");
                    }
                }



            }



        }
    }
}
