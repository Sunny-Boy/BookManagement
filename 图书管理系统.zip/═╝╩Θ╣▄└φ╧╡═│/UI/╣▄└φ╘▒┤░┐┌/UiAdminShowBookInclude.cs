﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UI.管理员窗口
{
    public partial class UiAdminShowBookInclude : Form
    {
        public UiAdminShowBookInclude()
        {
            InitializeComponent();
        }

        private void UiAdminShowBookInclude_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“bookManagementDataSet2.recommend_books_table”中。您可以根据需要移动或删除它。
            this.recommend_books_tableTableAdapter.Fill(this.bookManagementDataSet2.recommend_books_table);


            string sql1 = $"select *from recommend_books_table";//推书推荐
            string strConn = "uid=sa;pwd=admin123;database=BookManagement;server=XTZJ-20220423MW";//SQL Server链接字符串
            SqlConnection conn = new SqlConnection(strConn);
            SqlDataAdapter sda1 = new SqlDataAdapter(sql1, conn);
            DataTable dt1 = new DataTable();//dt是一个表类型。
            sda1.Fill(dt1);//把sda读取的数据填到dt里
            dataGridView1.DataSource = dt1;//把dt的内容绑定到Gridview1里显示

        }

        private void refresh_Click(object sender, EventArgs e)
        {
            this.bookIncludeBox.Text = "";

            string sql1 = $"select *from recommend_books_table";//推书推荐
            string strConn = "uid=sa;pwd=admin123;database=BookManagement;server=XTZJ-20220423MW";//SQL Server链接字符串
            SqlConnection conn = new SqlConnection(strConn);
            SqlDataAdapter sda1 = new SqlDataAdapter(sql1, conn);
            DataTable dt1 = new DataTable();//dt是一个表类型。
            sda1.Fill(dt1);//把sda读取的数据填到dt里
            dataGridView1.DataSource = dt1;//把dt的内容绑定到Gridview1里显示
        }

        private void findButton_Click(object sender, EventArgs e)
        {
            if(bookIncludeBox.Text == string.Empty)
            {
                string sql1 = $"select *from recommend_books_table";//推书推荐
                string strConn = "uid=sa;pwd=admin123;database=BookManagement;server=XTZJ-20220423MW";//SQL Server链接字符串
                SqlConnection conn = new SqlConnection(strConn);
                SqlDataAdapter sda1 = new SqlDataAdapter(sql1, conn);
                DataTable dt1 = new DataTable();//dt是一个表类型。
                sda1.Fill(dt1);//把sda读取的数据填到dt里
                dataGridView1.DataSource = dt1;//把dt的内容绑定到Gridview1里显示
            }
            else
            {
                string data = bookIncludeBox.Text;
                string sql1 = $"select *from recommend_books_table where book_name='{data}'";//推书推荐
                string strConn = "uid=sa;pwd=admin123;database=BookManagement;server=XTZJ-20220423MW";//SQL Server链接字符串
                SqlConnection conn = new SqlConnection(strConn);
                SqlDataAdapter sda1 = new SqlDataAdapter(sql1, conn);
                DataTable dt1 = new DataTable();//dt是一个表类型。
                sda1.Fill(dt1);//把sda读取的数据填到dt里
                dataGridView1.DataSource = dt1;//把dt的内容绑定到Gridview1里显示
            }
        }
    }
}
