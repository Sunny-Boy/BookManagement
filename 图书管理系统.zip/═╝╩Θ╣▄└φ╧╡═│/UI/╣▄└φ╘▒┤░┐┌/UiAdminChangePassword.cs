﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using Model;


namespace UI.管理员窗口
{
    public partial class UiAdminChangePassword : Form
    {
        public UiAdminChangePassword()
        {
            InitializeComponent();
        }

        private void UiAdminChangePassword_Load(object sender, EventArgs e)
        {
            ModelAdminUserTable adminTable = new BllAdminUserOperationAPI().FindAdminUserInfo(UiLogin.globalUserName);
            this.username.Text = adminTable.id;
            this.position.Text = adminTable.position;
        }

        private void changeButton_Click(object sender, EventArgs e)
        {
            string oldPassword = this.oldPassword.Text;
            string newPassword1 = this.newPassword1.Text;
            string newPassword2 = this.newPassword2.Text;

            if(oldPassword==string.Empty || newPassword1 == string.Empty || newPassword2==string.Empty)
            {
                MessageBox.Show("信息不能为空！");

            }
            else if (newPassword1.Length < 6 && newPassword2.Length < 6)
            {
                MessageBox.Show("为了安全起见，输入的密码必须大于6位！");
            }
            else
            {
                if (newPassword1 != newPassword2)
                {
                    MessageBox.Show("两次输入的密码不一样，请重新输入！");

                }
                else
                {
                    ModelAdminUserTable adminTable = new BllAdminUserOperationAPI().FindAdminUserInfo(this.username.Text);

                    if (oldPassword!=adminTable.password)
                    {
                        MessageBox.Show("输入的旧密码错误！");
                    }
                    else
                    {
                        int admin = new BllAdminUserOperationAPI().ChangePersonalInfo("password",newPassword2,UiLogin.globalUserName);
                        if (admin > 0)
                        {
                            this.oldPassword.Text = "";
                            this.newPassword1.Text = "";
                            this.newPassword2.Text = "";

                            MessageBox.Show("密码修改成功！");
                        }
                        else {
                            MessageBox.Show("密码修改失败，请检查输入的内容！");
                        }


                    }





                }

            }
        }
    }
}
