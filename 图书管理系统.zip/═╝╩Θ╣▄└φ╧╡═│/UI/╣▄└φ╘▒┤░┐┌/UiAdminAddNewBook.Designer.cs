﻿namespace UI.管理员窗口
{
    partial class UiAdminAddNewBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UiAdminAddNewBook));
            this.label1 = new System.Windows.Forms.Label();
            this.book_id = new System.Windows.Forms.TextBox();
            this.book_name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.book_author = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.book_price = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.book_inventory = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.book_location = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.book_press = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.book_abstract = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(229, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "编号：";
            // 
            // book_id
            // 
            this.book_id.Location = new System.Drawing.Point(290, 109);
            this.book_id.Name = "book_id";
            this.book_id.Size = new System.Drawing.Size(218, 25);
            this.book_id.TabIndex = 1;
            // 
            // book_name
            // 
            this.book_name.Location = new System.Drawing.Point(290, 140);
            this.book_name.Name = "book_name";
            this.book_name.Size = new System.Drawing.Size(218, 25);
            this.book_name.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(229, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "书名：";
            // 
            // book_author
            // 
            this.book_author.Location = new System.Drawing.Point(290, 171);
            this.book_author.Name = "book_author";
            this.book_author.Size = new System.Drawing.Size(218, 25);
            this.book_author.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(229, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "作者：";
            // 
            // book_price
            // 
            this.book_price.Location = new System.Drawing.Point(290, 202);
            this.book_price.Name = "book_price";
            this.book_price.Size = new System.Drawing.Size(218, 25);
            this.book_price.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(229, 205);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "价格：";
            // 
            // book_inventory
            // 
            this.book_inventory.Location = new System.Drawing.Point(290, 326);
            this.book_inventory.Name = "book_inventory";
            this.book_inventory.Size = new System.Drawing.Size(218, 25);
            this.book_inventory.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(229, 329);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "库存量：";
            // 
            // book_location
            // 
            this.book_location.Location = new System.Drawing.Point(290, 295);
            this.book_location.Name = "book_location";
            this.book_location.Size = new System.Drawing.Size(218, 25);
            this.book_location.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(229, 298);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 15);
            this.label6.TabIndex = 12;
            this.label6.Text = "位置：";
            // 
            // book_press
            // 
            this.book_press.Location = new System.Drawing.Point(290, 264);
            this.book_press.Name = "book_press";
            this.book_press.Size = new System.Drawing.Size(218, 25);
            this.book_press.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(229, 267);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 15);
            this.label7.TabIndex = 10;
            this.label7.Text = "出版社：";
            // 
            // book_abstract
            // 
            this.book_abstract.Location = new System.Drawing.Point(290, 233);
            this.book_abstract.Name = "book_abstract";
            this.book_abstract.Size = new System.Drawing.Size(218, 25);
            this.book_abstract.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(229, 236);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 15);
            this.label8.TabIndex = 8;
            this.label8.Text = "摘要：";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(232, 376);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 32);
            this.button1.TabIndex = 16;
            this.button1.Text = "添加图书";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(405, 376);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 32);
            this.button2.TabIndex = 17;
            this.button2.Text = "重新输入";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("站酷快乐体 ", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(262, 33);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(223, 53);
            this.label9.TabIndex = 18;
            this.label9.Text = "新书入库";
            // 
            // UiAdminAddNewBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(786, 467);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.book_inventory);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.book_location);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.book_press);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.book_abstract);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.book_price);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.book_author);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.book_name);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.book_id);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "UiAdminAddNewBook";
            this.Text = "添加新书";
            this.Load += new System.EventHandler(this.UiAdminAddNewBook_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox book_id;
        private System.Windows.Forms.TextBox book_name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox book_author;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox book_price;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox book_inventory;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox book_location;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox book_press;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox book_abstract;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label9;
    }
}