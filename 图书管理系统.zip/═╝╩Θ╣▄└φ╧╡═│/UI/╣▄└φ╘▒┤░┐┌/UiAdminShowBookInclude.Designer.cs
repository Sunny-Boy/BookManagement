﻿namespace UI.管理员窗口
{
    partial class UiAdminShowBookInclude
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UiAdminShowBookInclude));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.booknameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookauthorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.linkDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reasonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.useridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.useracademyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchasesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.recommendbookstableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookManagementDataSet2 = new UI.BookManagementDataSet2();
            this.findButton = new System.Windows.Forms.Button();
            this.bookIncludeBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.refresh = new System.Windows.Forms.Button();
            this.recommend_books_tableTableAdapter = new UI.BookManagementDataSet2TableAdapters.recommend_books_tableTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.recommendbookstableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.booknameDataGridViewTextBoxColumn,
            this.bookauthorDataGridViewTextBoxColumn,
            this.linkDataGridViewTextBoxColumn,
            this.reasonDataGridViewTextBoxColumn,
            this.useridDataGridViewTextBoxColumn,
            this.useracademyDataGridViewTextBoxColumn,
            this.purchasesDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.recommendbookstableBindingSource;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridView1.Location = new System.Drawing.Point(0, 55);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(1129, 526);
            this.dataGridView1.TabIndex = 0;
            // 
            // booknameDataGridViewTextBoxColumn
            // 
            this.booknameDataGridViewTextBoxColumn.DataPropertyName = "book_name";
            this.booknameDataGridViewTextBoxColumn.HeaderText = "书名";
            this.booknameDataGridViewTextBoxColumn.Name = "booknameDataGridViewTextBoxColumn";
            this.booknameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bookauthorDataGridViewTextBoxColumn
            // 
            this.bookauthorDataGridViewTextBoxColumn.DataPropertyName = "book_author";
            this.bookauthorDataGridViewTextBoxColumn.HeaderText = "作者";
            this.bookauthorDataGridViewTextBoxColumn.Name = "bookauthorDataGridViewTextBoxColumn";
            this.bookauthorDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // linkDataGridViewTextBoxColumn
            // 
            this.linkDataGridViewTextBoxColumn.DataPropertyName = "link";
            this.linkDataGridViewTextBoxColumn.HeaderText = "购买链接";
            this.linkDataGridViewTextBoxColumn.Name = "linkDataGridViewTextBoxColumn";
            this.linkDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // reasonDataGridViewTextBoxColumn
            // 
            this.reasonDataGridViewTextBoxColumn.DataPropertyName = "reason";
            this.reasonDataGridViewTextBoxColumn.HeaderText = "理由";
            this.reasonDataGridViewTextBoxColumn.Name = "reasonDataGridViewTextBoxColumn";
            this.reasonDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // useridDataGridViewTextBoxColumn
            // 
            this.useridDataGridViewTextBoxColumn.DataPropertyName = "user_id";
            this.useridDataGridViewTextBoxColumn.HeaderText = "推荐人";
            this.useridDataGridViewTextBoxColumn.Name = "useridDataGridViewTextBoxColumn";
            this.useridDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // useracademyDataGridViewTextBoxColumn
            // 
            this.useracademyDataGridViewTextBoxColumn.DataPropertyName = "user_academy";
            this.useracademyDataGridViewTextBoxColumn.HeaderText = "推荐人院校";
            this.useracademyDataGridViewTextBoxColumn.Name = "useracademyDataGridViewTextBoxColumn";
            this.useracademyDataGridViewTextBoxColumn.ReadOnly = true;
            this.useracademyDataGridViewTextBoxColumn.Width = 120;
            // 
            // purchasesDataGridViewTextBoxColumn
            // 
            this.purchasesDataGridViewTextBoxColumn.DataPropertyName = "purchases";
            this.purchasesDataGridViewTextBoxColumn.HeaderText = "是否购买";
            this.purchasesDataGridViewTextBoxColumn.Name = "purchasesDataGridViewTextBoxColumn";
            this.purchasesDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // recommendbookstableBindingSource
            // 
            this.recommendbookstableBindingSource.DataMember = "recommend_books_table";
            this.recommendbookstableBindingSource.DataSource = this.bookManagementDataSet2;
            // 
            // bookManagementDataSet2
            // 
            this.bookManagementDataSet2.DataSetName = "BookManagementDataSet2";
            this.bookManagementDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // findButton
            // 
            this.findButton.Location = new System.Drawing.Point(694, 21);
            this.findButton.Name = "findButton";
            this.findButton.Size = new System.Drawing.Size(105, 29);
            this.findButton.TabIndex = 10;
            this.findButton.Text = "查找";
            this.findButton.UseVisualStyleBackColor = true;
            this.findButton.Click += new System.EventHandler(this.findButton_Click);
            // 
            // bookIncludeBox
            // 
            this.bookIncludeBox.Location = new System.Drawing.Point(192, 21);
            this.bookIncludeBox.Name = "bookIncludeBox";
            this.bookIncludeBox.Size = new System.Drawing.Size(496, 25);
            this.bookIncludeBox.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(89, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "请输入书名：";
            // 
            // refresh
            // 
            this.refresh.Location = new System.Drawing.Point(805, 21);
            this.refresh.Name = "refresh";
            this.refresh.Size = new System.Drawing.Size(114, 29);
            this.refresh.TabIndex = 7;
            this.refresh.Text = "刷新";
            this.refresh.UseVisualStyleBackColor = true;
            this.refresh.Click += new System.EventHandler(this.refresh_Click);
            // 
            // recommend_books_tableTableAdapter
            // 
            this.recommend_books_tableTableAdapter.ClearBeforeFill = true;
            // 
            // UiAdminShowBookInclude
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1129, 581);
            this.Controls.Add(this.findButton);
            this.Controls.Add(this.bookIncludeBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.refresh);
            this.Controls.Add(this.dataGridView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UiAdminShowBookInclude";
            this.Text = "图书推荐查询";
            this.Load += new System.EventHandler(this.UiAdminShowBookInclude_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.recommendbookstableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button findButton;
        private System.Windows.Forms.TextBox bookIncludeBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button refresh;
        private BookManagementDataSet2 bookManagementDataSet2;
        private System.Windows.Forms.BindingSource recommendbookstableBindingSource;
        private BookManagementDataSet2TableAdapters.recommend_books_tableTableAdapter recommend_books_tableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn booknameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookauthorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn linkDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn reasonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn useridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn useracademyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchasesDataGridViewTextBoxColumn;
    }
}