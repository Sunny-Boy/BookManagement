﻿namespace UI.管理员窗口
{
    partial class UiAdminShowBorrowBooksRecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UiAdminShowBorrowBooksRecord));
            this.RefreshButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.FindBox = new System.Windows.Forms.TextBox();
            this.FindButton = new System.Windows.Forms.Button();
            this.bookManagementDataSet2 = new UI.BookManagementDataSet2();
            this.borrowinfotableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.borrowinfo_tableTableAdapter = new UI.BookManagementDataSet2TableAdapters.borrowinfo_tableTableAdapter();
            this.recommendbookstableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.recommend_books_tableTableAdapter = new UI.BookManagementDataSet2TableAdapters.recommend_books_tableTableAdapter();
            this.borrowinfotableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.booknameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.useridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.returntimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.borrowinfotableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.recommendbookstableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.borrowinfotableBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // RefreshButton
            // 
            this.RefreshButton.Location = new System.Drawing.Point(809, 29);
            this.RefreshButton.Name = "RefreshButton";
            this.RefreshButton.Size = new System.Drawing.Size(114, 29);
            this.RefreshButton.TabIndex = 3;
            this.RefreshButton.Text = "刷新";
            this.RefreshButton.UseVisualStyleBackColor = true;
            this.RefreshButton.Click += new System.EventHandler(this.RefreshButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.booknameDataGridViewTextBoxColumn,
            this.bookidDataGridViewTextBoxColumn,
            this.usernameDataGridViewTextBoxColumn,
            this.useridDataGridViewTextBoxColumn,
            this.timeDataGridViewTextBoxColumn,
            this.returntimeDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.borrowinfotableBindingSource;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridView1.Location = new System.Drawing.Point(0, 65);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(1022, 582);
            this.dataGridView1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(93, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "请输入书名：";
            // 
            // FindBox
            // 
            this.FindBox.Location = new System.Drawing.Point(196, 29);
            this.FindBox.Name = "FindBox";
            this.FindBox.Size = new System.Drawing.Size(496, 25);
            this.FindBox.TabIndex = 5;
            // 
            // FindButton
            // 
            this.FindButton.Location = new System.Drawing.Point(698, 29);
            this.FindButton.Name = "FindButton";
            this.FindButton.Size = new System.Drawing.Size(105, 29);
            this.FindButton.TabIndex = 6;
            this.FindButton.Text = "查找";
            this.FindButton.UseVisualStyleBackColor = true;
            this.FindButton.Click += new System.EventHandler(this.FindButton_Click);
            // 
            // bookManagementDataSet2
            // 
            this.bookManagementDataSet2.DataSetName = "BookManagementDataSet2";
            this.bookManagementDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // borrowinfotableBindingSource
            // 
            this.borrowinfotableBindingSource.DataMember = "borrowinfo_table";
            this.borrowinfotableBindingSource.DataSource = this.bookManagementDataSet2;
            // 
            // borrowinfo_tableTableAdapter
            // 
            this.borrowinfo_tableTableAdapter.ClearBeforeFill = true;
            // 
            // recommendbookstableBindingSource
            // 
            this.recommendbookstableBindingSource.DataMember = "recommend_books_table";
            this.recommendbookstableBindingSource.DataSource = this.bookManagementDataSet2;
            // 
            // recommend_books_tableTableAdapter
            // 
            this.recommend_books_tableTableAdapter.ClearBeforeFill = true;
            // 
            // borrowinfotableBindingSource1
            // 
            this.borrowinfotableBindingSource1.DataMember = "borrowinfo_table";
            this.borrowinfotableBindingSource1.DataSource = this.bookManagementDataSet2;
            // 
            // booknameDataGridViewTextBoxColumn
            // 
            this.booknameDataGridViewTextBoxColumn.DataPropertyName = "book_name";
            this.booknameDataGridViewTextBoxColumn.HeaderText = "书名";
            this.booknameDataGridViewTextBoxColumn.Name = "booknameDataGridViewTextBoxColumn";
            this.booknameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bookidDataGridViewTextBoxColumn
            // 
            this.bookidDataGridViewTextBoxColumn.DataPropertyName = "book_id";
            this.bookidDataGridViewTextBoxColumn.HeaderText = "书编号";
            this.bookidDataGridViewTextBoxColumn.Name = "bookidDataGridViewTextBoxColumn";
            this.bookidDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            this.usernameDataGridViewTextBoxColumn.DataPropertyName = "user_name";
            this.usernameDataGridViewTextBoxColumn.HeaderText = "借书人";
            this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            this.usernameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // useridDataGridViewTextBoxColumn
            // 
            this.useridDataGridViewTextBoxColumn.DataPropertyName = "user_id";
            this.useridDataGridViewTextBoxColumn.HeaderText = "学号";
            this.useridDataGridViewTextBoxColumn.Name = "useridDataGridViewTextBoxColumn";
            this.useridDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // timeDataGridViewTextBoxColumn
            // 
            this.timeDataGridViewTextBoxColumn.DataPropertyName = "time";
            this.timeDataGridViewTextBoxColumn.HeaderText = "借书时间";
            this.timeDataGridViewTextBoxColumn.Name = "timeDataGridViewTextBoxColumn";
            this.timeDataGridViewTextBoxColumn.ReadOnly = true;
            this.timeDataGridViewTextBoxColumn.Width = 130;
            // 
            // returntimeDataGridViewTextBoxColumn
            // 
            this.returntimeDataGridViewTextBoxColumn.DataPropertyName = "return_time";
            this.returntimeDataGridViewTextBoxColumn.HeaderText = "归还时间";
            this.returntimeDataGridViewTextBoxColumn.Name = "returntimeDataGridViewTextBoxColumn";
            this.returntimeDataGridViewTextBoxColumn.ReadOnly = true;
            this.returntimeDataGridViewTextBoxColumn.Width = 130;
            // 
            // UiAdminShowBorrowBooksRecord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 647);
            this.Controls.Add(this.FindButton);
            this.Controls.Add(this.FindBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RefreshButton);
            this.Controls.Add(this.dataGridView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "UiAdminShowBorrowBooksRecord";
            this.Text = "借书/还书记录查询";
            this.Load += new System.EventHandler(this.UiAdminShowBorrowBooksRecord_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.borrowinfotableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.recommendbookstableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.borrowinfotableBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button RefreshButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox FindBox;
        private System.Windows.Forms.Button FindButton;
        private BookManagementDataSet2 bookManagementDataSet2;
        private System.Windows.Forms.BindingSource borrowinfotableBindingSource;
        private BookManagementDataSet2TableAdapters.borrowinfo_tableTableAdapter borrowinfo_tableTableAdapter;
        private System.Windows.Forms.BindingSource recommendbookstableBindingSource;
        private BookManagementDataSet2TableAdapters.recommend_books_tableTableAdapter recommend_books_tableTableAdapter;
        private System.Windows.Forms.BindingSource borrowinfotableBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn booknameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn useridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn returntimeDataGridViewTextBoxColumn;
    }
}