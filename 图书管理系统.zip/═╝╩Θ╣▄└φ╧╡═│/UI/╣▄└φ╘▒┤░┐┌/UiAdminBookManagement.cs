﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using Model;
using System.Data.SqlClient;


namespace UI.管理员窗口
{
    public partial class UiAdminBookManagement : Form
    {
        public UiAdminBookManagement()
        {
            InitializeComponent();
        }
        string key = " ";
        string value = "";
        string bookname = "";


        private void UiAdminBookManagement_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“bookManagementDataSet2.book_table”中。您可以根据需要移动或删除它。
            this.book_tableTableAdapter.Fill(this.bookManagementDataSet2.book_table);

            string sql1 = $"select * from book_table";//推书推荐
            string strConn = "uid=sa;pwd=admin123;database=BookManagement;server=XTZJ-20220423MW";//SQL Server链接字符串
            SqlConnection conn = new SqlConnection(strConn);
            SqlDataAdapter sda1 = new SqlDataAdapter(sql1, conn);
            DataTable dt1 = new DataTable();//dt是一个表类型。
            sda1.Fill(dt1);//把sda读取的数据填到dt里
            dataGridView1.DataSource = dt1;//把dt的内容绑定到Gridview1里显示


            ModelAdminUserTable adminTable = new BllAdminUserOperationAPI().FindAdminUserInfo(UiLogin.globalUserName);
            this.username.Text = adminTable.id;
            this.position.Text = adminTable.position;

        }


        //选中修改属性值
        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (dataGridView1.Rows.Count == 0)
            {

            }
            else
            {
                int a = dataGridView1.CurrentRow.Index;
                this.selectBook.Text = (string)dataGridView1.Rows[a].Cells["idDataGridViewTextBoxColumn"].Value + " " + (string)dataGridView1.Rows[a].Cells["nameDataGridViewTextBoxColumn"].Value;
                this.DataTemp.Text = this.dataGridView1.Columns[this.dataGridView1.CurrentCell.ColumnIndex].HeaderText;
                bookname = (string)dataGridView1.Rows[a].Cells["nameDataGridViewTextBoxColumn"].Value;

            }
        }

        //删除图书
        private void button1_Click(object sender, EventArgs e)
        {
            if (bookname == string.Empty)
            {
                MessageBox.Show("请指定好要删除的书籍！");
            }
            else
            {
                int delBookOp = new BllAdminUserOperationAPI().DelBook(bookname);
                if (delBookOp > 0)
                {
                    MessageBox.Show("删除成功！");
                    this.Close();
                    UiAdminBookManagement bookMan = new UiAdminBookManagement();
                    bookMan.ShowDialog();
                    this.DataValue.Text = "";
                }
                else
                {
                    MessageBox.Show("删除失败！");
                }
            }

 
        }

        //修改图书
        private void button2_Click(object sender, EventArgs e)
        {

            key = this.dataGridView1.Columns[this.dataGridView1.CurrentCell.ColumnIndex].DataPropertyName;
            value = this.DataValue.Text;
            

            int ModifyBookInfo = new BllAdminUserOperationAPI().ModifyBookInfo(key,value, bookname);
            if (ModifyBookInfo > 0)
            {
                MessageBox.Show("修改成功！");
                OnLoad(null);
                this.DataValue.Text = "";
            }
            else
            {
                MessageBox.Show("修改失败！");
            }

        }
    }
}
