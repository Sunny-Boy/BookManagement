﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using BLL;


namespace UI.管理员窗口
{
    public partial class UiAdminPersonalInfo : Form
    {
        public UiAdminPersonalInfo()
        {
            InitializeComponent();
        }

        private void UiAdminPersonalInfo_Load(object sender, EventArgs e)
        {
            ModelAdminUserTable adminInfo = new BllAdminUserOperationAPI().FindAdminUserInfo(UiLogin.globalUserName);
            this.username.Text = adminInfo.id;
            this.password.Text = adminInfo.password;

            this.username2.Text = adminInfo.id;
            this.name.Text = adminInfo.name;
            this.position.Text = adminInfo.position;
            this.phone.Text = adminInfo.phone;
            this.address.Text = adminInfo.address;
            this.note.Text = adminInfo.note;

            this.changeUsername.Text = adminInfo.id;
            this.createTime.Text = adminInfo.create_time;


        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.ShowPassword.Checked == false)
            {
                this.password.PasswordChar = '*';
                ShowPassword.Text = "显示";
            }
            else
            {
                this.password.PasswordChar = '\0';
                ShowPassword.Text = "隐藏";
            }
        }

        private void AddAdminButton_Click(object sender, EventArgs e)
        {
            int num = 0;

            if (this.changeName.Text != string.Empty)
            {
                string value = this.changeName.Text;
                string key = "name";
                int i = new BllAdminUserOperationAPI().ChangePersonalInfo(key, value, UiLogin.globalUserName);
                if (i > 0) { num += 1; }
                this.changeName.Text = "";
            }

            if (this.changePosition.Text != string.Empty)
            {
                string value = this.changePosition.Text;
                string key = "position";
                int i = new BllAdminUserOperationAPI().ChangePersonalInfo(key, value, UiLogin.globalUserName);
                if (i > 0) { num += 1; }
                this.changePosition.Text = "";
            }

            if (this.changePhone.Text != string.Empty && this.changePhone.Text.Length == 11 || this.changePhone.Text.Length == 8)
            {
                string value = this.changePhone.Text;
                string key = "phone";
                int i = new BllAdminUserOperationAPI().ChangePersonalInfo(key,value,UiLogin.globalUserName);
                if (i > 0) { num += 1; }
                this.changePhone.Text = "";
            }

            if (this.changeAddress.Text != string.Empty)
            {
                string value = this.changeAddress.Text;
                string key = "address";
                int i = new BllAdminUserOperationAPI().ChangePersonalInfo(key, value, UiLogin.globalUserName);
                if (i > 0) { num += 1; }
                this.changeAddress.Text = "";
            }

            if (this.changeNote.Text != string.Empty)
            {
                string value = this.changeNote.Text;
                string key = "note";
                int i = new BllAdminUserOperationAPI().ChangePersonalInfo(key, value, UiLogin.globalUserName);
                if (i > 0) { num += 1; }
                this.changeNote.Text = "";
            }

            if (num == 0)
            {
                MessageBox.Show("输入信息不正确，未进行修改！");
            }
            else
            {
                MessageBox.Show("恭喜成功修改" + num + "条数据！");
                OnLoad(null);
            }



        }
    }
}
