﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using BLL;


namespace UI.管理员窗口
{
    public partial class UiAdminAddNewBook : Form
    {
        public UiAdminAddNewBook()
        {
            InitializeComponent();
        }

        //窗口加载事件
        private void UiAdminAddNewBook_Load(object sender, EventArgs e)
        {

        }

        //添加图书按钮
        private void button1_Click(object sender, EventArgs e)
        {
            /* 
             string book_id = this.book_id.Text;
             string book_name = this.book_name.Text;
             string book_author = this.book_author.Text;
             string book_price = this.book_price.Text;
             string book_abstract = this.book_abstract.Text;
             string book_press = this.book_press.Text;
             string book_location = this.book_location.Text;
             string book_inventory = this.book_inventory.Text;
             */

            if (this.book_id.Text==string.Empty || this.book_name.Text == string.Empty || this.book_author.Text == string.Empty || this.book_price.Text == string.Empty || this.book_abstract.Text == string.Empty || this.book_press.Text == string.Empty || this.book_location.Text == string.Empty || this.book_inventory.Text == string.Empty)
            {
                MessageBox.Show("数据不能为空，请检查核对后重新输入！");
            }
            else
            {
                string name = this.book_name.Text;
                ModelBookTable bookInfo = new BllAdminUserOperationAPI().FindBookTableInfo(name);
                if (name == bookInfo.name)
                {
                    MessageBox.Show("数据库已经有相同的书籍！");
                }
                else
                {

                    ModelBookTable bookTable = new ModelBookTable();
                    bookTable.id = this.book_id.Text;
                    bookTable.name = this.book_name.Text;
                    bookTable.author = this.book_author.Text;
                    bookTable.price = this.book_price.Text;
                    bookTable.book_abstract = this.book_abstract.Text;
                    bookTable.press = this.book_press.Text;
                    bookTable.location = this.book_location.Text;
                    bookTable.time = DateTime.Now.ToString();
                    bookTable.inventory = this.book_inventory.Text;
                    int addNewBook = new BllAdminUserOperationAPI().AddNewBook(bookTable);
                    if (addNewBook > 0)
                    {
                        MessageBox.Show("添加书籍成功！");
                        this.book_id.Text = "";
                        this.book_name.Text = "";
                        this.book_author.Text = "";
                        this.book_price.Text = "";
                        this.book_abstract.Text = "";
                        this.book_press.Text = "";
                        this.book_location.Text = "";
                        this.book_inventory.Text = "";

                    }
                    else
                    {
                        MessageBox.Show("添加书籍失败！");

                    }
                }
            
            }
        }

        //重新输入按钮
        private void button2_Click(object sender, EventArgs e)
        {
            this.book_id.Text = "";
            this.book_name.Text = "";
            this.book_author.Text = "";
            this.book_price.Text = "";
            this.book_abstract.Text = "";
            this.book_press.Text = "";
            this.book_location.Text = "";
            this.book_inventory.Text = "";
        }
    }
}
