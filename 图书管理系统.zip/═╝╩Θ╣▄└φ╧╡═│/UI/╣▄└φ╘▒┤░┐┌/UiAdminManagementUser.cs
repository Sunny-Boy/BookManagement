﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using BLL;
using Model;


namespace UI.管理员窗口
{
    public partial class UiAdminManagementUser : Form
    {
        public UiAdminManagementUser()
        {
            InitializeComponent();
        }

        string id = "";
        string DateState = "";

        //当前选中用户操作
        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (dataGridView1.Rows.Count == 0)
            {

            }
            else
            {
                int a = dataGridView1.CurrentRow.Index;
                this.selectUser.Text = (string)dataGridView1.Rows[a].Cells["idDataGridViewTextBoxColumn"].Value+" " +(string)dataGridView1.Rows[a].Cells["nameDataGridViewTextBoxColumn"].Value;
                id = (string)dataGridView1.Rows[a].Cells["idDataGridViewTextBoxColumn"].Value;
                DateState = (string)dataGridView1.Rows[a].Cells["stateDataGridViewTextBoxColumn"].Value;
            }
        }

        //删除用户
        private void button1_Click(object sender, EventArgs e)
        {
            int delOp = new BllAdminUserOperationAPI().DelCommonUser(id);
            if (delOp > 0)
            {
                MessageBox.Show("删除成功！");
                this.selectUser.Text = "";
                OnLoad(null);
            }
            else
            {
                MessageBox.Show("删除失败！");
            }

        }

        //设置用户状态
        private void button2_Click(object sender, EventArgs e)
        {
            if (DateState == "正常")
            {
                int state = new BllAdminUserOperationAPI().ChangeCommonState(id, "锁定");
                if(state>0)
                {
                    MessageBox.Show("状态修改成功！");

                    this.selectUser.Text = "";
                    OnLoad(null);
                }
                else
                {
                    MessageBox.Show("状态修改失败！");

                    this.selectUser.Text = "";
                }
            }
            else if(DateState=="锁定")
            {
                int state = new BllAdminUserOperationAPI().ChangeCommonState(id, "正常");
                if (state > 0)
                {
                    MessageBox.Show("状态修改成功！");

                    this.selectUser.Text = "";
                    OnLoad(null);
                }
                else
                {
                    MessageBox.Show("状态修改失败！");

                    this.selectUser.Text = "";
                }
            }

        }

        private void UiAdminManagementUser_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“bookManagementDataSet2.common_user_table”中。您可以根据需要移动或删除它。
            this.common_user_tableTableAdapter.Fill(this.bookManagementDataSet2.common_user_table);





            string sql1 = $"select id,password,name,gender,phone,QQ,academy,major,registration_time,borrow_book_num,note,state from common_user_table";//普通用户信息查询
            string strConn = "uid=sa;pwd=admin123;database=BookManagement;server=XTZJ-20220423MW";//SQL Server链接字符串
            SqlConnection conn = new SqlConnection(strConn);
            SqlDataAdapter sda1 = new SqlDataAdapter(sql1, conn);
            DataTable dt1 = new DataTable();//dt是一个表类型。
            sda1.Fill(dt1);//把sda读取的数据填到dt里
            dataGridView1.DataSource = dt1;//把dt的内容绑定到Gridview1里显示




            ModelAdminUserTable adminInfo = new BllAdminUserOperationAPI().FindAdminUserInfo(UiLogin.globalUserName);
            this.username.Text = adminInfo.id;
            this.position.Text = adminInfo.position;



        }
    }
}
