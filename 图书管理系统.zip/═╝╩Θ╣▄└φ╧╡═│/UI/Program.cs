﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // UiLogin login = new UiLogin();
            //if(login.ShowDialog()==DialogResult.OK)
            //{

            //  UiAdminUserWindow admin = new UiAdminUserWindow();


            Application.Run(new UiLogin());
            //}
            /*
            FrmLogin lg = new FrmLogin();
            if (lg.ShowDialog() == DialogResult.OK)
            {
                FrmMain zct = new FrmMain();
                zct.userActive = lg.LoginUser;
                Application.Run(zct);
            }
            */
            UiLogin lg =new UiLogin();
            if (lg.ShowDialog() == DialogResult.OK)
            {
                if (UiLogin.globaIdentity== "common_user_table")
                {
                    UiCommonUserWindow common = new UiCommonUserWindow();
                    Application.Run(common);
                }
                else if(UiLogin.globaIdentity == "admin_user_table")
                {
                    UiAdminUserWindow admin = new UiAdminUserWindow();
                    Application.Run(admin);
                }

                
               

                
            }

        }
    }
}
