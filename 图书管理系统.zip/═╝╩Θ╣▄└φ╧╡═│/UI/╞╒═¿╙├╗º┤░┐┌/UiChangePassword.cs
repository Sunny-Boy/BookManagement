﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using Model;


namespace UI
{
    public partial class UiChangePassword : Form
    {
        public UiChangePassword()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void UiChangePassword_Load(object sender, EventArgs e)
        {
            ModelCommonUser common = new BllCommonUserOperationAPI().QueryAllInfo(UiLogin.globalUserName);
            this.id.Text = UiLogin.globalUserName;
            this.major.Text = common.academy+common.major;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            string oldPassword = this.oldPassword.Text;
            ModelCommonUser info = new BllCommonUserOperationAPI().QueryAllInfo(UiLogin.globalUserName);
            if (this.oldPassword.Text==string.Empty)
            {
                MessageBox.Show("请输入旧密码！");
            }
            else if (this.newPassword1.Text==string.Empty&&this.newPassword1.Text.Length < 6)
            {
                MessageBox.Show("请输入正确的新密码！");
            }
            else
            {
                if (this.oldPassword.Text == info.password)
                {
                    if (this.newPassword1.Text == this.newPassword2.Text)
                    {

                        string newPassword1 = this.newPassword1.Text;
                        string newPassword2 = this.newPassword2.Text;

                        int i = new BllCommonUserOperationAPI().ChangePassword(UiLogin.globalUserName, newPassword1);
                        if (i > 0)
                        {
                            MessageBox.Show("恭喜你，密码修改成功！", "系统提示");
                            this.oldPassword.Text = "\0";
                            this.newPassword1.Text = "\0";
                            this.newPassword2.Text = "\0";
                        }
                        else
                        {
                            MessageBox.Show("密码修改失败，请检查后重新输入", "系统提示");
                        }

                    }
                    else
                    {
                        MessageBox.Show("两次输入的新密码不一样，请重新输入！！！", "系统提示");
                    }
                }
                else
                {
                    MessageBox.Show("输入的旧密码错误，请重新输入！！！");
                }
            }


            
        }
    }
}
