﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using BLL;
using System.Data.SqlClient;

namespace UI
{
    public partial class UiCommonReturnBook : Form
    {
        public UiCommonReturnBook()
        {
            InitializeComponent();
        }
        string book_id = "1";
        private void UiCommonReturnBook_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“bookManagementDataSet2.borrowinfo_table”中。您可以根据需要移动或删除它。
            this.borrowinfo_tableTableAdapter.Fill(this.bookManagementDataSet2.borrowinfo_table);
            ModelCommonUser user = new BllCommonUserOperationAPI().QueryAllInfo(UiLogin.globalUserName);
            this.username.Text = UiLogin.globalUserName;
            this.borrowCount.Text = user.borrow_book_num.ToString();

            string sql = $"select *from borrowinfo_table where user_id='{UiLogin.globalUserName}'and return_time='暂未归还'";
            string strConn = "uid=sa;pwd=admin123;database=BookManagement;server=XTZJ-20220423MW";//SQL Server链接字符串
            SqlConnection conn = new SqlConnection(strConn);
            SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();//dt是一个表类型。
            sda.Fill(dt);//把sda读取的数据填到dt里
            dataGridView1.DataSource = dt;//把dt的内容绑定到Gridview1里显示
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("对不起，当前未选中还书记录！");
            }
            else
            {
                int a = dataGridView1.CurrentRow.Index;
                this.selectedBook.Text = (string)dataGridView1.Rows[a].Cells["booknameDataGridViewTextBoxColumn"].Value;
                book_id = (string)dataGridView1.Rows[a].Cells["bookidDataGridViewTextBoxColumn"].Value;

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*
           /// 1、修改借书记录里面的还书时间
        /// 2、修改图书信息里面的库存量
            */

            int returnTime = new BllCommonUserOperationAPI().UpdataBorrowInfo(selectedBook.Text, UiLogin.globalUserName);
            int returnUserInfo = new BllCommonUserOperationAPI().UpdataBookTableInvento(this.selectedBook.Text);
            if (returnTime > 0 && returnUserInfo > 0)
            {

                MessageBox.Show("成功还书！");
                this.OnLoad(null);
            }
            else
            {
                MessageBox.Show("returnTime:" + returnTime+ "\nreturnUserInfo:" + returnUserInfo);
            }
        }

        private void borrowCount_Click(object sender, EventArgs e)
        {

        }

        private void selectedBook_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
