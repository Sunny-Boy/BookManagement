﻿namespace UI
{
    partial class UiCommonShowAndModifyInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UiCommonShowAndModifyInfo));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ShowPassword = new System.Windows.Forms.CheckBox();
            this.BoxPassword = new System.Windows.Forms.TextBox();
            this.TextUsername1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TextBorrowNum = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.TextRegistrationTime = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.TextNote = new System.Windows.Forms.Label();
            this.TextMajor = new System.Windows.Forms.Label();
            this.TextAcademy = new System.Windows.Forms.Label();
            this.TextQQ = new System.Windows.Forms.Label();
            this.TextPhone = new System.Windows.Forms.Label();
            this.TextGender = new System.Windows.Forms.Label();
            this.TextName = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.TextUsername2 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBoxPhone = new System.Windows.Forms.TextBox();
            this.textBoxMajor = new System.Windows.Forms.TextBox();
            this.textBoxAcademy = new System.Windows.Forms.TextBox();
            this.textBoxQQ = new System.Windows.Forms.TextBox();
            this.textBoxNote = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox1.Controls.Add(this.ShowPassword);
            this.groupBox1.Controls.Add(this.BoxPassword);
            this.groupBox1.Controls.Add(this.TextUsername1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(482, 150);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "账号信息";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // ShowPassword
            // 
            this.ShowPassword.AutoSize = true;
            this.ShowPassword.Location = new System.Drawing.Point(317, 74);
            this.ShowPassword.Name = "ShowPassword";
            this.ShowPassword.Size = new System.Drawing.Size(59, 19);
            this.ShowPassword.TabIndex = 17;
            this.ShowPassword.Text = "显示";
            this.ShowPassword.UseVisualStyleBackColor = true;
            this.ShowPassword.CheckedChanged += new System.EventHandler(this.ShowPassword_CheckedChanged);
            // 
            // BoxPassword
            // 
            this.BoxPassword.Enabled = false;
            this.BoxPassword.Location = new System.Drawing.Point(92, 72);
            this.BoxPassword.Name = "BoxPassword";
            this.BoxPassword.PasswordChar = '*';
            this.BoxPassword.Size = new System.Drawing.Size(216, 25);
            this.BoxPassword.TabIndex = 16;
            // 
            // TextUsername1
            // 
            this.TextUsername1.AutoSize = true;
            this.TextUsername1.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.TextUsername1.Location = new System.Drawing.Point(89, 37);
            this.TextUsername1.Name = "TextUsername1";
            this.TextUsername1.Size = new System.Drawing.Size(15, 15);
            this.TextUsername1.TabIndex = 14;
            this.TextUsername1.Text = "1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(31, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "密码：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(31, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "学号：";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox2.Controls.Add(this.TextBorrowNum);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.TextRegistrationTime);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.TextNote);
            this.groupBox2.Controls.Add(this.TextMajor);
            this.groupBox2.Controls.Add(this.TextAcademy);
            this.groupBox2.Controls.Add(this.TextQQ);
            this.groupBox2.Controls.Add(this.TextPhone);
            this.groupBox2.Controls.Add(this.TextGender);
            this.groupBox2.Controls.Add(this.TextName);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.groupBox2.Location = new System.Drawing.Point(12, 170);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(482, 266);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "资料信息";
            // 
            // TextBorrowNum
            // 
            this.TextBorrowNum.AutoSize = true;
            this.TextBorrowNum.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TextBorrowNum.Location = new System.Drawing.Point(314, 71);
            this.TextBorrowNum.Name = "TextBorrowNum";
            this.TextBorrowNum.Size = new System.Drawing.Size(15, 15);
            this.TextBorrowNum.TabIndex = 17;
            this.TextBorrowNum.Text = "1";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(226, 71);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 15);
            this.label12.TabIndex = 16;
            this.label12.Text = "借书数量：";
            // 
            // TextRegistrationTime
            // 
            this.TextRegistrationTime.AutoSize = true;
            this.TextRegistrationTime.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TextRegistrationTime.Location = new System.Drawing.Point(314, 36);
            this.TextRegistrationTime.Name = "TextRegistrationTime";
            this.TextRegistrationTime.Size = new System.Drawing.Size(15, 15);
            this.TextRegistrationTime.TabIndex = 15;
            this.TextRegistrationTime.Text = "1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(226, 36);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 15);
            this.label11.TabIndex = 14;
            this.label11.Text = "注册时间：";
            // 
            // TextNote
            // 
            this.TextNote.AutoSize = true;
            this.TextNote.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TextNote.Location = new System.Drawing.Point(89, 217);
            this.TextNote.Name = "TextNote";
            this.TextNote.Size = new System.Drawing.Size(15, 15);
            this.TextNote.TabIndex = 13;
            this.TextNote.Text = "1";
            // 
            // TextMajor
            // 
            this.TextMajor.AutoSize = true;
            this.TextMajor.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TextMajor.Location = new System.Drawing.Point(89, 188);
            this.TextMajor.Name = "TextMajor";
            this.TextMajor.Size = new System.Drawing.Size(15, 15);
            this.TextMajor.TabIndex = 12;
            this.TextMajor.Text = "1";
            // 
            // TextAcademy
            // 
            this.TextAcademy.AutoSize = true;
            this.TextAcademy.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TextAcademy.Location = new System.Drawing.Point(89, 159);
            this.TextAcademy.Name = "TextAcademy";
            this.TextAcademy.Size = new System.Drawing.Size(15, 15);
            this.TextAcademy.TabIndex = 11;
            this.TextAcademy.Text = "1";
            // 
            // TextQQ
            // 
            this.TextQQ.AutoSize = true;
            this.TextQQ.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TextQQ.Location = new System.Drawing.Point(89, 131);
            this.TextQQ.Name = "TextQQ";
            this.TextQQ.Size = new System.Drawing.Size(15, 15);
            this.TextQQ.TabIndex = 10;
            this.TextQQ.Text = "1";
            // 
            // TextPhone
            // 
            this.TextPhone.AutoSize = true;
            this.TextPhone.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TextPhone.Location = new System.Drawing.Point(89, 102);
            this.TextPhone.Name = "TextPhone";
            this.TextPhone.Size = new System.Drawing.Size(15, 15);
            this.TextPhone.TabIndex = 9;
            this.TextPhone.Text = "1";
            // 
            // TextGender
            // 
            this.TextGender.AutoSize = true;
            this.TextGender.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TextGender.Location = new System.Drawing.Point(89, 71);
            this.TextGender.Name = "TextGender";
            this.TextGender.Size = new System.Drawing.Size(15, 15);
            this.TextGender.TabIndex = 8;
            this.TextGender.Text = "1";
            // 
            // TextName
            // 
            this.TextName.AutoSize = true;
            this.TextName.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.TextName.Location = new System.Drawing.Point(89, 36);
            this.TextName.Name = "TextName";
            this.TextName.Size = new System.Drawing.Size(15, 15);
            this.TextName.TabIndex = 7;
            this.TextName.Text = "1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(28, 217);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 15);
            this.label9.TabIndex = 6;
            this.label9.Text = "备注：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(28, 188);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 15);
            this.label8.TabIndex = 5;
            this.label8.Text = "专业：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(28, 159);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 15);
            this.label7.TabIndex = 4;
            this.label7.Text = "院校：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(31, 131);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 15);
            this.label6.TabIndex = 3;
            this.label6.Text = "Q Q：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(31, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "电话：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(31, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 15);
            this.label4.TabIndex = 1;
            this.label4.Text = "性别：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(31, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "姓名：";
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(526, 387);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(309, 37);
            this.button1.TabIndex = 2;
            this.button1.Text = "立即修改";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // TextUsername2
            // 
            this.TextUsername2.AutoSize = true;
            this.TextUsername2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.TextUsername2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TextUsername2.Location = new System.Drawing.Point(581, 49);
            this.TextUsername2.Name = "TextUsername2";
            this.TextUsername2.Size = new System.Drawing.Size(15, 15);
            this.TextUsername2.TabIndex = 17;
            this.TextUsername2.Text = "1";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label20.Location = new System.Drawing.Point(523, 49);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(52, 15);
            this.label20.TabIndex = 16;
            this.label20.Text = "学号：";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label21.Location = new System.Drawing.Point(523, 324);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(52, 15);
            this.label21.TabIndex = 20;
            this.label21.Text = "备注：";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label22.Location = new System.Drawing.Point(523, 267);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(52, 15);
            this.label22.TabIndex = 19;
            this.label22.Text = "专业：";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label23.Location = new System.Drawing.Point(522, 211);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(52, 15);
            this.label23.TabIndex = 18;
            this.label23.Text = "院校：";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label24.Location = new System.Drawing.Point(528, 158);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(46, 15);
            this.label24.TabIndex = 17;
            this.label24.Text = "Q Q：";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label25.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label25.Location = new System.Drawing.Point(523, 102);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(52, 15);
            this.label25.TabIndex = 16;
            this.label25.Text = "电话：";
            // 
            // textBoxPhone
            // 
            this.textBoxPhone.Location = new System.Drawing.Point(579, 98);
            this.textBoxPhone.Name = "textBoxPhone";
            this.textBoxPhone.Size = new System.Drawing.Size(256, 25);
            this.textBoxPhone.TabIndex = 23;
            // 
            // textBoxMajor
            // 
            this.textBoxMajor.Location = new System.Drawing.Point(579, 262);
            this.textBoxMajor.Name = "textBoxMajor";
            this.textBoxMajor.Size = new System.Drawing.Size(256, 25);
            this.textBoxMajor.TabIndex = 26;
            // 
            // textBoxAcademy
            // 
            this.textBoxAcademy.Location = new System.Drawing.Point(579, 206);
            this.textBoxAcademy.Name = "textBoxAcademy";
            this.textBoxAcademy.Size = new System.Drawing.Size(256, 25);
            this.textBoxAcademy.TabIndex = 25;
            // 
            // textBoxQQ
            // 
            this.textBoxQQ.Location = new System.Drawing.Point(579, 152);
            this.textBoxQQ.Name = "textBoxQQ";
            this.textBoxQQ.Size = new System.Drawing.Size(256, 25);
            this.textBoxQQ.TabIndex = 24;
            // 
            // textBoxNote
            // 
            this.textBoxNote.Location = new System.Drawing.Point(579, 319);
            this.textBoxNote.Name = "textBoxNote";
            this.textBoxNote.Size = new System.Drawing.Size(256, 25);
            this.textBoxNote.TabIndex = 27;
            // 
            // UiCommonShowAndModifyInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::UI.Properties.Resources._11;
            this.ClientSize = new System.Drawing.Size(890, 450);
            this.Controls.Add(this.textBoxNote);
            this.Controls.Add(this.textBoxMajor);
            this.Controls.Add(this.textBoxAcademy);
            this.Controls.Add(this.textBoxQQ);
            this.Controls.Add(this.textBoxPhone);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.TextUsername2);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "UiCommonShowAndModifyInfo";
            this.Text = "查看和修改个人信息";
            this.Load += new System.EventHandler(this.UiShowAndModifyInfo_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label TextNote;
        private System.Windows.Forms.Label TextMajor;
        private System.Windows.Forms.Label TextAcademy;
        private System.Windows.Forms.Label TextQQ;
        private System.Windows.Forms.Label TextPhone;
        private System.Windows.Forms.Label TextGender;
        private System.Windows.Forms.Label TextName;
        private System.Windows.Forms.Label TextUsername1;
        private System.Windows.Forms.Label TextUsername2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBoxPhone;
        private System.Windows.Forms.TextBox textBoxMajor;
        private System.Windows.Forms.TextBox textBoxAcademy;
        private System.Windows.Forms.TextBox textBoxQQ;
        private System.Windows.Forms.TextBox textBoxNote;
        private System.Windows.Forms.TextBox BoxPassword;
        private System.Windows.Forms.Label TextRegistrationTime;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label TextBorrowNum;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox ShowPassword;
    }
}