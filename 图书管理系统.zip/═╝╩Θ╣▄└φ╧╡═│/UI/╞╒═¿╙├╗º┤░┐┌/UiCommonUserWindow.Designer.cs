﻿namespace UI
{
    partial class UiCommonUserWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UiCommonUserWindow));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.statusBottom1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusWelcomeUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusAuthorityLevels = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusCurrentState = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusCurrentTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.ShowAndModifyTool = new System.Windows.Forms.ToolStripButton();
            this.ModifyPasswordTool = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.BookRecomTool = new System.Windows.Forms.ToolStripButton();
            this.BorrowBooksTool = new System.Windows.Forms.ToolStripButton();
            this.ReturnBooksTool = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.FindBooksTool = new System.Windows.Forms.ToolStripButton();
            this.BorrowingRecordsTool = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.HelpTool = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新用户注册 = new System.Windows.Forms.ToolStripMenuItem();
            this.用户信息修改ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改信息 = new System.Windows.Forms.ToolStripMenuItem();
            this.修改密码 = new System.Windows.Forms.ToolStripMenuItem();
            this.锁定用户 = new System.Windows.Forms.ToolStripMenuItem();
            this.注销用户 = new System.Windows.Forms.ToolStripMenuItem();
            this.管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新书入库 = new System.Windows.Forms.ToolStripMenuItem();
            this.借书 = new System.Windows.Forms.ToolStripMenuItem();
            this.还书 = new System.Windows.Forms.ToolStripMenuItem();
            this.书籍注销 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关于软件 = new System.Windows.Forms.ToolStripMenuItem();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.nameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.authorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.borrownumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.booktableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookManagementDataSet2 = new UI.BookManagementDataSet2();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.academyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.borrowbooknumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commonusertableBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.commonusertableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.bookManagementDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookManagementDataSet1 = new UI.BookManagementDataSet1();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.nameDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.authorDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inventory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.booktableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.bookManagementDataSet = new UI.BookManagementDataSet();
            this.bookManagementDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.commonusertableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.common_user_tableTableAdapter = new UI.BookManagementDataSetTableAdapters.common_user_tableTableAdapter();
            this.common_user_tableTableAdapter1 = new UI.BookManagementDataSet2TableAdapters.common_user_tableTableAdapter();
            this.book_tableTableAdapter = new UI.BookManagementDataSet2TableAdapters.book_tableTableAdapter();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.booktableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commonusertableBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commonusertableBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet1)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.booktableBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commonusertableBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusBottom1,
            this.statusWelcomeUser,
            this.statusAuthorityLevels,
            this.statusCurrentState,
            this.statusCurrentTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 695);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1517, 25);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip1_ItemClicked);
            // 
            // statusBottom1
            // 
            this.statusBottom1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.statusBottom1.Margin = new System.Windows.Forms.Padding(5, 3, 0, 2);
            this.statusBottom1.Name = "statusBottom1";
            this.statusBottom1.Size = new System.Drawing.Size(0, 20);
            // 
            // statusWelcomeUser
            // 
            this.statusWelcomeUser.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.statusWelcomeUser.Name = "statusWelcomeUser";
            this.statusWelcomeUser.Size = new System.Drawing.Size(374, 20);
            this.statusWelcomeUser.Spring = true;
            this.statusWelcomeUser.Text = "欢迎xxx, 进入图书管理系统";
            this.statusWelcomeUser.Click += new System.EventHandler(this.statusWelcomeUser_Click);
            // 
            // statusAuthorityLevels
            // 
            this.statusAuthorityLevels.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.statusAuthorityLevels.Name = "statusAuthorityLevels";
            this.statusAuthorityLevels.Size = new System.Drawing.Size(374, 20);
            this.statusAuthorityLevels.Spring = true;
            this.statusAuthorityLevels.Text = "权限级别：普通用户";
            this.statusAuthorityLevels.Click += new System.EventHandler(this.toolStripStatusLabel3_Click);
            // 
            // statusCurrentState
            // 
            this.statusCurrentState.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.statusCurrentState.Name = "statusCurrentState";
            this.statusCurrentState.Size = new System.Drawing.Size(374, 20);
            this.statusCurrentState.Spring = true;
            this.statusCurrentState.Text = "当前状态：正常";
            this.statusCurrentState.Click += new System.EventHandler(this.statusCurrentState_Click);
            // 
            // statusCurrentTime
            // 
            this.statusCurrentTime.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.statusCurrentTime.Name = "statusCurrentTime";
            this.statusCurrentTime.Size = new System.Drawing.Size(374, 20);
            this.statusCurrentTime.Spring = true;
            this.statusCurrentTime.Text = "当前时间：1";
            this.statusCurrentTime.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.statusCurrentTime.Click += new System.EventHandler(this.statusCurrentTime_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolStrip1.BackgroundImage")));
            this.toolStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ShowAndModifyTool,
            this.ModifyPasswordTool,
            this.toolStripSeparator1,
            this.BookRecomTool,
            this.BorrowBooksTool,
            this.ReturnBooksTool,
            this.toolStripSeparator2,
            this.FindBooksTool,
            this.BorrowingRecordsTool,
            this.toolStripSeparator3,
            this.HelpTool,
            this.toolStripSeparator4});
            this.toolStrip1.Location = new System.Drawing.Point(0, 28);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1517, 66);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // ShowAndModifyTool
            // 
            this.ShowAndModifyTool.AutoSize = false;
            this.ShowAndModifyTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ShowAndModifyTool.Image = ((System.Drawing.Image)(resources.GetObject("ShowAndModifyTool.Image")));
            this.ShowAndModifyTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ShowAndModifyTool.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.ShowAndModifyTool.Name = "ShowAndModifyTool";
            this.ShowAndModifyTool.Size = new System.Drawing.Size(49, 44);
            this.ShowAndModifyTool.Text = "用户信息查看和修改";
            this.ShowAndModifyTool.Click += new System.EventHandler(this.ShowAndModifyTool_Click);
            // 
            // ModifyPasswordTool
            // 
            this.ModifyPasswordTool.AutoSize = false;
            this.ModifyPasswordTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ModifyPasswordTool.Image = ((System.Drawing.Image)(resources.GetObject("ModifyPasswordTool.Image")));
            this.ModifyPasswordTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ModifyPasswordTool.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.ModifyPasswordTool.Name = "ModifyPasswordTool";
            this.ModifyPasswordTool.Size = new System.Drawing.Size(49, 44);
            this.ModifyPasswordTool.Text = "修改密码";
            this.ModifyPasswordTool.Click += new System.EventHandler(this.ModifyPasswordTool_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.AutoSize = false;
            this.toolStripSeparator1.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(7, 45);
            // 
            // BookRecomTool
            // 
            this.BookRecomTool.AutoSize = false;
            this.BookRecomTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BookRecomTool.Image = ((System.Drawing.Image)(resources.GetObject("BookRecomTool.Image")));
            this.BookRecomTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BookRecomTool.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.BookRecomTool.Name = "BookRecomTool";
            this.BookRecomTool.Size = new System.Drawing.Size(49, 44);
            this.BookRecomTool.Text = "图书推荐";
            this.BookRecomTool.Click += new System.EventHandler(this.BookRecomTool_Click);
            // 
            // BorrowBooksTool
            // 
            this.BorrowBooksTool.AutoSize = false;
            this.BorrowBooksTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BorrowBooksTool.Image = ((System.Drawing.Image)(resources.GetObject("BorrowBooksTool.Image")));
            this.BorrowBooksTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BorrowBooksTool.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.BorrowBooksTool.Name = "BorrowBooksTool";
            this.BorrowBooksTool.Size = new System.Drawing.Size(49, 44);
            this.BorrowBooksTool.Text = "借书办理";
            this.BorrowBooksTool.Click += new System.EventHandler(this.BorrowBooksTool_Click);
            // 
            // ReturnBooksTool
            // 
            this.ReturnBooksTool.AutoSize = false;
            this.ReturnBooksTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ReturnBooksTool.Image = ((System.Drawing.Image)(resources.GetObject("ReturnBooksTool.Image")));
            this.ReturnBooksTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ReturnBooksTool.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.ReturnBooksTool.Name = "ReturnBooksTool";
            this.ReturnBooksTool.Size = new System.Drawing.Size(49, 44);
            this.ReturnBooksTool.Text = "还书办理";
            this.ReturnBooksTool.Click += new System.EventHandler(this.ReturnBooksTool_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.AutoSize = false;
            this.toolStripSeparator2.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(7, 45);
            // 
            // FindBooksTool
            // 
            this.FindBooksTool.AutoSize = false;
            this.FindBooksTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.FindBooksTool.Image = ((System.Drawing.Image)(resources.GetObject("FindBooksTool.Image")));
            this.FindBooksTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.FindBooksTool.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.FindBooksTool.Name = "FindBooksTool";
            this.FindBooksTool.Size = new System.Drawing.Size(49, 44);
            this.FindBooksTool.Text = "查找书籍";
            this.FindBooksTool.Click += new System.EventHandler(this.FindBooksTool_Click);
            // 
            // BorrowingRecordsTool
            // 
            this.BorrowingRecordsTool.AutoSize = false;
            this.BorrowingRecordsTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BorrowingRecordsTool.Image = ((System.Drawing.Image)(resources.GetObject("BorrowingRecordsTool.Image")));
            this.BorrowingRecordsTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BorrowingRecordsTool.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.BorrowingRecordsTool.Name = "BorrowingRecordsTool";
            this.BorrowingRecordsTool.Size = new System.Drawing.Size(49, 44);
            this.BorrowingRecordsTool.Text = "查询借书记录";
            this.BorrowingRecordsTool.Click += new System.EventHandler(this.BorrowingRecordsTool_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.AutoSize = false;
            this.toolStripSeparator3.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(7, 45);
            // 
            // HelpTool
            // 
            this.HelpTool.AutoSize = false;
            this.HelpTool.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.HelpTool.Image = ((System.Drawing.Image)(resources.GetObject("HelpTool.Image")));
            this.HelpTool.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.HelpTool.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.HelpTool.Name = "HelpTool";
            this.HelpTool.Size = new System.Drawing.Size(49, 44);
            this.HelpTool.Text = "帮助";
            this.HelpTool.Click += new System.EventHandler(this.HelpTool_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.AutoSize = false;
            this.toolStripSeparator4.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(7, 45);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Enabled = false;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.系统ToolStripMenuItem,
            this.管理ToolStripMenuItem,
            this.toolStripMenuItem2,
            this.帮助ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1517, 28);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // 系统ToolStripMenuItem
            // 
            this.系统ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新用户注册,
            this.用户信息修改ToolStripMenuItem,
            this.锁定用户,
            this.注销用户});
            this.系统ToolStripMenuItem.Name = "系统ToolStripMenuItem";
            this.系统ToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.系统ToolStripMenuItem.Text = "系统管理(S)";
            // 
            // 新用户注册
            // 
            this.新用户注册.Name = "新用户注册";
            this.新用户注册.Size = new System.Drawing.Size(174, 26);
            this.新用户注册.Text = "新用户注册";
            // 
            // 用户信息修改ToolStripMenuItem
            // 
            this.用户信息修改ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.修改信息,
            this.修改密码});
            this.用户信息修改ToolStripMenuItem.Name = "用户信息修改ToolStripMenuItem";
            this.用户信息修改ToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.用户信息修改ToolStripMenuItem.Text = "用户信息修改";
            // 
            // 修改信息
            // 
            this.修改信息.Name = "修改信息";
            this.修改信息.Size = new System.Drawing.Size(144, 26);
            this.修改信息.Text = "修改信息";
            // 
            // 修改密码
            // 
            this.修改密码.Name = "修改密码";
            this.修改密码.Size = new System.Drawing.Size(144, 26);
            this.修改密码.Text = "修改密码";
            // 
            // 锁定用户
            // 
            this.锁定用户.Name = "锁定用户";
            this.锁定用户.Size = new System.Drawing.Size(174, 26);
            this.锁定用户.Text = "锁定用户处理";
            // 
            // 注销用户
            // 
            this.注销用户.Name = "注销用户";
            this.注销用户.Size = new System.Drawing.Size(174, 26);
            this.注销用户.Text = "注销用户";
            // 
            // 管理ToolStripMenuItem
            // 
            this.管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新书入库,
            this.借书,
            this.还书,
            this.书籍注销});
            this.管理ToolStripMenuItem.Name = "管理ToolStripMenuItem";
            this.管理ToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.管理ToolStripMenuItem.Text = "书籍管理(B)";
            // 
            // 新书入库
            // 
            this.新书入库.Name = "新书入库";
            this.新书入库.Size = new System.Drawing.Size(144, 26);
            this.新书入库.Text = "新书入库";
            // 
            // 借书
            // 
            this.借书.Name = "借书";
            this.借书.Size = new System.Drawing.Size(144, 26);
            this.借书.Text = "借书办理";
            // 
            // 还书
            // 
            this.还书.Name = "还书";
            this.还书.Size = new System.Drawing.Size(144, 26);
            this.还书.Text = "还书办理";
            // 
            // 书籍注销
            // 
            this.书籍注销.Name = "书籍注销";
            this.书籍注销.Size = new System.Drawing.Size(144, 26);
            this.书籍注销.Text = "书籍注销";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(100, 24);
            this.toolStripMenuItem2.Text = "信息查询(P)";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(174, 26);
            this.toolStripMenuItem3.Text = "图书查询";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(174, 26);
            this.toolStripMenuItem4.Text = "借书单查询";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(174, 26);
            this.toolStripMenuItem5.Text = "用户信息查询";
            // 
            // 帮助ToolStripMenuItem
            // 
            this.帮助ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.关于软件});
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(73, 24);
            this.帮助ToolStripMenuItem.Text = "帮助(H)";
            // 
            // 关于软件
            // 
            this.关于软件.Name = "关于软件";
            this.关于软件.Size = new System.Drawing.Size(181, 26);
            this.关于软件.Text = "关于软件";
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox1.Controls.Add(this.dataGridView3);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Location = new System.Drawing.Point(726, 123);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(397, 251);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "热门图书排行";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn1,
            this.authorDataGridViewTextBoxColumn,
            this.borrownumDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.booktableBindingSource;
            this.dataGridView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView3.Location = new System.Drawing.Point(3, 21);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dataGridView3.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView3.RowTemplate.Height = 27;
            this.dataGridView3.Size = new System.Drawing.Size(391, 227);
            this.dataGridView3.TabIndex = 1;
            // 
            // nameDataGridViewTextBoxColumn1
            // 
            this.nameDataGridViewTextBoxColumn1.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn1.HeaderText = "书名";
            this.nameDataGridViewTextBoxColumn1.Name = "nameDataGridViewTextBoxColumn1";
            this.nameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // authorDataGridViewTextBoxColumn
            // 
            this.authorDataGridViewTextBoxColumn.DataPropertyName = "author";
            this.authorDataGridViewTextBoxColumn.HeaderText = "作者";
            this.authorDataGridViewTextBoxColumn.Name = "authorDataGridViewTextBoxColumn";
            this.authorDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // borrownumDataGridViewTextBoxColumn
            // 
            this.borrownumDataGridViewTextBoxColumn.DataPropertyName = "borrow_num";
            this.borrownumDataGridViewTextBoxColumn.HeaderText = "借阅数量";
            this.borrownumDataGridViewTextBoxColumn.Name = "borrownumDataGridViewTextBoxColumn";
            this.borrownumDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // booktableBindingSource
            // 
            this.booktableBindingSource.DataMember = "book_table";
            this.booktableBindingSource.DataSource = this.bookManagementDataSet2;
            // 
            // bookManagementDataSet2
            // 
            this.bookManagementDataSet2.DataSetName = "BookManagementDataSet2";
            this.bookManagementDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 21);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(391, 227);
            this.dataGridView1.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox2.Controls.Add(this.dataGridView6);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox2.Location = new System.Drawing.Point(1129, 123);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(388, 470);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "借阅书籍排行";
            // 
            // dataGridView6
            // 
            this.dataGridView6.AllowUserToAddRows = false;
            this.dataGridView6.AllowUserToDeleteRows = false;
            this.dataGridView6.AutoGenerateColumns = false;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.academyDataGridViewTextBoxColumn,
            this.borrowbooknumDataGridViewTextBoxColumn});
            this.dataGridView6.DataSource = this.commonusertableBindingSource2;
            this.dataGridView6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView6.Location = new System.Drawing.Point(3, 21);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.ReadOnly = true;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.dataGridView6.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView6.RowTemplate.Height = 27;
            this.dataGridView6.Size = new System.Drawing.Size(382, 446);
            this.dataGridView6.TabIndex = 7;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "姓名";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Width = 85;
            // 
            // academyDataGridViewTextBoxColumn
            // 
            this.academyDataGridViewTextBoxColumn.DataPropertyName = "academy";
            this.academyDataGridViewTextBoxColumn.HeaderText = "院校";
            this.academyDataGridViewTextBoxColumn.Name = "academyDataGridViewTextBoxColumn";
            this.academyDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // borrowbooknumDataGridViewTextBoxColumn
            // 
            this.borrowbooknumDataGridViewTextBoxColumn.DataPropertyName = "borrow_book_num";
            this.borrowbooknumDataGridViewTextBoxColumn.HeaderText = "借书数量";
            this.borrowbooknumDataGridViewTextBoxColumn.Name = "borrowbooknumDataGridViewTextBoxColumn";
            this.borrowbooknumDataGridViewTextBoxColumn.ReadOnly = true;
            this.borrowbooknumDataGridViewTextBoxColumn.Width = 95;
            // 
            // commonusertableBindingSource2
            // 
            this.commonusertableBindingSource2.DataMember = "common_user_table";
            this.commonusertableBindingSource2.DataSource = this.bookManagementDataSet2;
            // 
            // commonusertableBindingSource1
            // 
            this.commonusertableBindingSource1.DataMember = "common_user_table";
            this.commonusertableBindingSource1.DataSource = this.bookManagementDataSet1BindingSource;
            // 
            // bookManagementDataSet1BindingSource
            // 
            this.bookManagementDataSet1BindingSource.DataSource = this.bookManagementDataSet1;
            this.bookManagementDataSet1BindingSource.Position = 0;
            // 
            // bookManagementDataSet1
            // 
            this.bookManagementDataSet1.DataSetName = "BookManagementDataSet1";
            this.bookManagementDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox3.Controls.Add(this.dataGridView2);
            this.groupBox3.Controls.Add(this.dataGridView4);
            this.groupBox3.Controls.Add(this.dataGridView5);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox3.Location = new System.Drawing.Point(725, 377);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(398, 213);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "新上图书";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn2,
            this.authorDataGridViewTextBoxColumn1,
            this.inventory});
            this.dataGridView2.DataSource = this.booktableBindingSource1;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 21);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView2.RowTemplate.Height = 27;
            this.dataGridView2.Size = new System.Drawing.Size(392, 189);
            this.dataGridView2.TabIndex = 2;
            // 
            // nameDataGridViewTextBoxColumn2
            // 
            this.nameDataGridViewTextBoxColumn2.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn2.HeaderText = "书名";
            this.nameDataGridViewTextBoxColumn2.Name = "nameDataGridViewTextBoxColumn2";
            this.nameDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // authorDataGridViewTextBoxColumn1
            // 
            this.authorDataGridViewTextBoxColumn1.DataPropertyName = "author";
            this.authorDataGridViewTextBoxColumn1.HeaderText = "作者";
            this.authorDataGridViewTextBoxColumn1.Name = "authorDataGridViewTextBoxColumn1";
            this.authorDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // inventory
            // 
            this.inventory.DataPropertyName = "inventory";
            this.inventory.HeaderText = "库存";
            this.inventory.Name = "inventory";
            this.inventory.ReadOnly = true;
            // 
            // booktableBindingSource1
            // 
            this.booktableBindingSource1.DataMember = "book_table";
            this.booktableBindingSource1.DataSource = this.bookManagementDataSet2;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView4.Location = new System.Drawing.Point(3, 21);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 27;
            this.dataGridView4.Size = new System.Drawing.Size(392, 189);
            this.dataGridView4.TabIndex = 1;
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView5.Location = new System.Drawing.Point(3, 21);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowTemplate.Height = 27;
            this.dataGridView5.Size = new System.Drawing.Size(392, 189);
            this.dataGridView5.TabIndex = 0;
            // 
            // bookManagementDataSet
            // 
            this.bookManagementDataSet.DataSetName = "BookManagementDataSet";
            this.bookManagementDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bookManagementDataSetBindingSource
            // 
            this.bookManagementDataSetBindingSource.DataSource = this.bookManagementDataSet;
            this.bookManagementDataSetBindingSource.Position = 0;
            // 
            // commonusertableBindingSource
            // 
            this.commonusertableBindingSource.DataMember = "common_user_table";
            this.commonusertableBindingSource.DataSource = this.bookManagementDataSetBindingSource;
            // 
            // common_user_tableTableAdapter
            // 
            this.common_user_tableTableAdapter.ClearBeforeFill = true;
            // 
            // common_user_tableTableAdapter1
            // 
            this.common_user_tableTableAdapter1.ClearBeforeFill = true;
            // 
            // book_tableTableAdapter
            // 
            this.book_tableTableAdapter.ClearBeforeFill = true;
            // 
            // UiCommonUserWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::UI.Properties.Resources._171;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1517, 720);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.statusStrip1);
            this.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UiCommonUserWindow";
            this.Text = "图书管理系统";
            this.Load += new System.EventHandler(this.UiCommonUserWindow_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.booktableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commonusertableBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commonusertableBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.booktableBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookManagementDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commonusertableBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel statusBottom1;
        private System.Windows.Forms.ToolStripStatusLabel statusWelcomeUser;
        private System.Windows.Forms.ToolStripStatusLabel statusAuthorityLevels;
        private System.Windows.Forms.ToolStripStatusLabel statusCurrentState;
        private System.Windows.Forms.ToolStripStatusLabel statusCurrentTime;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton BookRecomTool;
        private System.Windows.Forms.ToolStripButton ShowAndModifyTool;
        private System.Windows.Forms.ToolStripButton ModifyPasswordTool;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton BorrowBooksTool;
        private System.Windows.Forms.ToolStripButton ReturnBooksTool;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton FindBooksTool;
        private System.Windows.Forms.ToolStripButton BorrowingRecordsTool;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新用户注册;
        private System.Windows.Forms.ToolStripMenuItem 用户信息修改ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改信息;
        private System.Windows.Forms.ToolStripMenuItem 修改密码;
        private System.Windows.Forms.ToolStripMenuItem 锁定用户;
        private System.Windows.Forms.ToolStripMenuItem 注销用户;
        private System.Windows.Forms.ToolStripMenuItem 管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新书入库;
        private System.Windows.Forms.ToolStripMenuItem 借书;
        private System.Windows.Forms.ToolStripMenuItem 还书;
        private System.Windows.Forms.ToolStripMenuItem 书籍注销;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于软件;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripButton HelpTool;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.BindingSource bookManagementDataSetBindingSource;
       
        private System.Windows.Forms.BindingSource commonusertableBindingSource;
        private System.Windows.Forms.BindingSource bookManagementDataSet1BindingSource;
       
        private System.Windows.Forms.BindingSource commonusertableBindingSource1;
        private BookManagementDataSet bookManagementDataSet;
        private BookManagementDataSetTableAdapters.common_user_tableTableAdapter common_user_tableTableAdapter;
        private BookManagementDataSet1 bookManagementDataSet1;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.DataGridView dataGridView2;
        private BookManagementDataSet2 bookManagementDataSet2;
        private System.Windows.Forms.BindingSource commonusertableBindingSource2;
        private BookManagementDataSet2TableAdapters.common_user_tableTableAdapter common_user_tableTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn academyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn borrowbooknumDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource booktableBindingSource;
        private BookManagementDataSet2TableAdapters.book_tableTableAdapter book_tableTableAdapter;
        private System.Windows.Forms.BindingSource booktableBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn authorDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn inventory;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn authorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn borrownumDataGridViewTextBoxColumn;


        /*
        
        
            this.common_user_tableTableAdapter1 = new UI.BookManagementDataSet1TableAdapters.common_user_tableTableAdapter();
             this.common_user_tableTableAdapter1.ClearBeforeFill = true;
        */
    }
}