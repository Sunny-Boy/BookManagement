﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using BLL;


namespace UI
{
    public partial class UiCommonShowAndModifyInfo : Form
    {
        public UiCommonShowAndModifyInfo()
        {
            InitializeComponent();
        }

        private void UiShowAndModifyInfo_Load(object sender, EventArgs e)
        {
            ModelCommonUser common = new BllCommonUserOperationAPI().QueryAllInfo(UiLogin.globalUserName);

            this.TextUsername1.Text = UiLogin.globalUserName;
            this.TextUsername2.Text = UiLogin.globalUserName;


            this.BoxPassword.Text = common.password;
            this.TextName.Text = common.name;
            this.TextAcademy.Text = common.academy;

            this.TextGender.Text = common.gender;
            this.TextPhone.Text = common.phone;
            this.TextQQ.Text = common.QQ;
            this.TextMajor.Text = common.major;

            this.TextRegistrationTime.Text = common.registration_time;
            this.TextNote.Text = common.note;
            this.TextBorrowNum.Text = common.borrow_book_num.ToString();

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num = 0;
            /*  if (this.textBoxName.Text != string.Empty)
              {
                  string temp = this.textBoxName.Text;
                  string name = "name";
                  int i = new BllCommonUserOperationAPI().UpdateInfo(UiLogin.globalUserName,name,temp);
                  if (i > 0){num += 1;}
              }

              if (this.textBoxGender.Text != string.Empty)
              {
                  string temp = this.textBoxGender.Text;
                  string name = "gender";
                  int i = new BllCommonUserOperationAPI().UpdateInfo(UiLogin.globalUserName, name, temp);
                  if (i > 0) { num += 1; }
              }*/

            if (this.textBoxPhone.Text != string.Empty && this.textBoxPhone.Text.Length == 11 || this.textBoxPhone.Text.Length == 8)
            {
                string temp = this.textBoxPhone.Text;
                string name = "phone";
                int i = new BllCommonUserOperationAPI().UpdateInfo(UiLogin.globalUserName, name, temp);
                if (i > 0) { num += 1; }
            }



            if (this.textBoxQQ.Text != string.Empty && this.textBoxPhone.Text.Length >=5 && this.textBoxPhone.Text.Length <= 12)
            {
                string temp = this.textBoxQQ.Text;
                string name = "QQ";
                int i = new BllCommonUserOperationAPI().UpdateInfo(UiLogin.globalUserName, name, temp);
                if (i > 0) { num += 1; }
            }

            if (this.textBoxAcademy.Text != string.Empty)
            {
                string temp = this.textBoxAcademy.Text;
                string name = "academy";
                int i = new BllCommonUserOperationAPI().UpdateInfo(UiLogin.globalUserName, name, temp);
                if (i > 0) { num += 1; }
            }

            if (this.textBoxMajor.Text != string.Empty)
            {
                string temp = this.textBoxMajor.Text;
                string name = "major";
                int i = new BllCommonUserOperationAPI().UpdateInfo(UiLogin.globalUserName, name, temp);
                if (i > 0) { num += 1; }
            }
            if (this.textBoxNote.Text != string.Empty)
            {
                string temp = this.textBoxNote.Text;
                string name = "note";
                int i = new BllCommonUserOperationAPI().UpdateInfo(UiLogin.globalUserName, name, temp);
                if (i > 0) { num += 1; }
            }
            if (num == 0)
            {
                MessageBox.Show("输入信息不正确，未进行修改！");
            }
            else
            {
                MessageBox.Show("恭喜成功修改" + num + "条数据！");
                OnLoad(null);
            }

           
        }

        /// <summary>
        /// 显示密码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ShowPassword1_Click(object sender, EventArgs e)
        {
            this.BoxPassword.PasswordChar = '\0';


        }







        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void ShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (ShowPassword.Checked)
            {
                BoxPassword.PasswordChar = '\0';
                ShowPassword.Text = "隐藏";
            }
            else
            {
                BoxPassword.PasswordChar = '*';
                ShowPassword.Text = "显示";
            }
        }
    }
}
