﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using Model;
using System.Data.SqlClient;


namespace UI
{
    public partial class UiCommonBorrowBooks : Form
    {
        public UiCommonBorrowBooks()
        {
            InitializeComponent();
        }

        private void dataGridViewDateShow(string name)
        {
            string sql = $"select *from book_table where name='{name}'";
            string strConn = "uid=sa;pwd=admin123;database=BookManagement;server=XTZJ-20220423MW";//SQL Server链接字符串
            SqlConnection conn = new SqlConnection(strConn);
            SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();//dt是一个表类型。
            sda.Fill(dt);//把sda读取的数据填到dt里
            dataGridView1.DataSource = dt;//把dt的内容绑定到Gridview1里显示
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string name = this.BookName.Text;

            dataGridViewDateShow(name);

        }

       


        private void button3_Click(object sender, EventArgs e)
        {
            


            if (this.selectedBox.Text==string.Empty)
            {
                MessageBox.Show("还没有进行选中书籍！");
            }
            else
            {
                ModelBookTable bookinfo = new BllCommonUserOperationAPI().BorrowBook(BookName.Text);
                if (string.Compare(bookinfo.inventory, "0") > 0)
                {
                    
                    ModelBorrowInfo info = new ModelBorrowInfo();
                    ModelCommonUser userInfo = new BllCommonUserOperationAPI().QueryAllInfo(UiLogin.globalUserName);
                    info.book_name = bookinfo.name;
                    info.book_id = bookinfo.id;
                    info.user_name = userInfo.name;
                    info.user_id = UiLogin.globalUserName;
                    info.time = DateTime.Now.ToString();

                    int i = new BllCommonUserOperationAPI().BorrowBookOp(info);

                    int j = new BllCommonUserOperationAPI().UpdateBookInventory(bookinfo);
                    int k = new BllCommonUserOperationAPI().UpdateUserBorrowInfo(UiLogin.globalUserName);
                    MessageBox.Show("借书成功！！！");
                    this.selectedBox.Text = "";
                    string name = this.BookName.Text;
                    dataGridViewDateShow(name);
                }
                else
                {
                    MessageBox.Show("借书失败，当前书在馆数量为" + bookinfo.inventory);
                }
            }



        }

        private void UiCommonBorrowBooks_Load(object sender, EventArgs e)
        {

            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if(dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("当前还没有书籍！");
            }
            else
            {
                int a = dataGridView1.CurrentRow.Index;
                this.selectedBox.Text = (string)dataGridView1.Rows[a].Cells["nameDataGridViewTextBoxColumn"].Value;

            }
        }
    }
}
