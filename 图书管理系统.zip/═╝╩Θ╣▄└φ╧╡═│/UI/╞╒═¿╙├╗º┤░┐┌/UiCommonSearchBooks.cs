﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using BLL;
using System.Data.SqlClient;


namespace UI
{
    public partial class UiCommonSearchBooks : Form
    {
        public UiCommonSearchBooks()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            

            string sql = $"select *from book_table where name='{this.findBook.Text}'";
            string strConn = "uid=sa;pwd=admin123;database=BookManagement;server=XTZJ-20220423MW";//SQL Server链接字符串
            SqlConnection conn = new SqlConnection(strConn);
            SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();//dt是一个表类型。
            sda.Fill(dt);//把sda读取的数据填到dt里
            dataGridView1.DataSource = dt;//把dt的内容绑定到Gridview1里显示
        }

        private void UiCommonSearchBooks_Load(object sender, EventArgs e)
        {

        }
    }
}
