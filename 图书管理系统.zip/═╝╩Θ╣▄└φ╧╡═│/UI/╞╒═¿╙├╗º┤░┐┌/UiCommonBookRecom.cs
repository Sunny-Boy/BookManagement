﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using Model;
using System.Data.SqlClient;

namespace UI
{
    public partial class UiCommonBookRecom : Form
    {
        public UiCommonBookRecom()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void UiCommonBookRecom_Load(object sender, EventArgs e)
        {
            ModelCommonUser common = new BllCommonUserOperationAPI().QueryAllInfo(UiLogin.globalUserName);
            this.username.Text = UiLogin.globalUserName;
            this.academy_major.Text = common.academy;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.name.Text = "\0";
            this.author.Text = "\0";
            this.link.Text = "\0";
            this.reson.Text = "\0";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string book_name = this.name.Text;
            string author = this.author.Text;
            string link = this.link.Text;
            string reason = this.reson.Text;
            string id = this.username.Text;
            string academy = this.academy_major.Text;

            if (book_name==string.Empty&& author == string.Empty&& link == string.Empty&& reason == string.Empty)
            {
                MessageBox.Show("不允许为空，请把推荐信息输入完整！");
            }
            else
           {
                ModelRecommendBooks recommend = new ModelRecommendBooks();
                recommend.book_name = book_name;
                recommend.book_author = author;
                recommend.reason = reason;
                recommend.link = link;
                recommend.user_id = id;
                recommend.user_academy = this.academy_major.Text;
                ModelBookTable booktable = new BllCommonUserOperationAPI().FindRepeatBook(book_name);
                if (book_name == booktable.name)
                {
                    MessageBox.Show("该书在本馆已存在，请转到查找图书进行查找！");
                }
                else
                {
                    int num = new BllCommonUserOperationAPI().IntroduceBookInfo(recommend);

                    if (num > 0)
                    {
                        MessageBox.Show("推荐成功！！！");
                        this.name.Text = "\0";
                        this.author.Text = "\0";
                        this.link.Text = "\0";
                        this.reson.Text = "\0";
                    }
                    else
                    {
                        MessageBox.Show("推荐失败！！！");
                    }
                }

            }
        }

        private void academy_major_Click(object sender, EventArgs e)
        {

        }
    }
}
