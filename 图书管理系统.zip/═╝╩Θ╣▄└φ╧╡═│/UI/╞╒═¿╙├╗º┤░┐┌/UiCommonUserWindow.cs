﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using Model;
using System.Data.SqlClient;

namespace UI
{
    public partial class UiCommonUserWindow : Form
    {
        public UiCommonUserWindow()
        {
            InitializeComponent();
            this.statusCurrentTime.Text = "当前时间：" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");//在程序刚加载，就进行时间获取
        }

        /// <summary>
        /// 用户查看和修改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ShowAndModifyTool_Click(object sender, EventArgs e)
        {
            UiCommonShowAndModifyInfo showandmodify = new UiCommonShowAndModifyInfo();
            showandmodify.ShowDialog();

        }

        /// <summary>
        /// 修改用户密码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ModifyPasswordTool_Click(object sender, EventArgs e)
        {
            UiChangePassword changepassword = new UiChangePassword();
            changepassword.ShowDialog();
        }

        /// <summary>
        /// 图书推荐
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BookRecomTool_Click(object sender, EventArgs e)
        {
            UiCommonBookRecom bookrecom = new UiCommonBookRecom();
            bookrecom.ShowDialog();
        }


        /// <summary>
        /// 借书办理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BorrowBooksTool_Click(object sender, EventArgs e)
        {
            UiCommonBorrowBooks borrowbooks = new UiCommonBorrowBooks();
            borrowbooks.ShowDialog();

        }

        /// <summary>
        /// 还书办理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ReturnBooksTool_Click(object sender, EventArgs e)
        {
            UiCommonReturnBook returnbooks = new UiCommonReturnBook();
            returnbooks.ShowDialog();

        }

        /// <summary>
        /// 查找书籍
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FindBooksTool_Click(object sender, EventArgs e)
        {
            UiCommonSearchBooks searchbooks = new UiCommonSearchBooks();
            searchbooks.ShowDialog();
        }

        /// <summary>
        /// 查阅借书记录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BorrowingRecordsTool_Click(object sender, EventArgs e)
        {
            UiCommonBorrowRecord borrowrecord = new UiCommonBorrowRecord();
            borrowrecord.ShowDialog();
        }

        /// <summary>
        /// 帮助
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HelpTool_Click(object sender, EventArgs e)
        {
            UiHelp help = new UiHelp();
            help.ShowDialog();

        }

        /// <summary>
        /// 番茄钟
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PomodoroTool_Click(object sender, EventArgs e)
        {
            UiPomodoro pomodoro = new UiPomodoro();
            pomodoro.ShowDialog();
        }



        /// <summary>
        /// 顶部菜单栏
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }


        

        /// <summary>
        /// 底部状态栏
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        private void statusWelcomeUser_Click(object sender, EventArgs e)
        {
            //欢迎语

            

        }

        private void statusCurrentState_Click(object sender, EventArgs e)
        {
            //当前状态

        }

        private void statusCurrentTime_Click(object sender, EventArgs e)
        {
            //当前时间
           
        }

        /// <summary>
        /// 加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UiCommonUserWindow_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“bookManagementDataSet2.book_table”中。您可以根据需要移动或删除它。
            this.book_tableTableAdapter.Fill(this.bookManagementDataSet2.book_table);
            // TODO: 这行代码将数据加载到表“bookManagementDataSet2.common_user_table”中。您可以根据需要移动或删除它。
            this.common_user_tableTableAdapter1.Fill(this.bookManagementDataSet2.common_user_table);

            ModelCommonUser common = new BllCommonUserOperationAPI().QueryState(UiLogin.globalUserName);
            this.statusWelcomeUser.Text =  "欢迎 "+ UiLogin.globalUserName + " 用户登陆图书管理系统！";
            this.statusAuthorityLevels.Text = "权限级别：" + UiLogin.globaLevel;
            this.statusCurrentState.Text = "当前状态：" + common.state;
            timer.Interval = 1000;
            timer.Start();

            //排行榜
            string sql1 = $"select name,academy,borrow_book_num from common_user_table order by borrow_book_num desc";//借阅图书人排行榜
            string sql2 = $"select name,author,borrow_num from book_table order by borrow_num desc";//图书热借排行榜
            string sql3 = $"select name,author,inventory from book_table order by ORDER BY  unix_timestamp(time) desc";
            string strConn = "uid=sa;pwd=admin123;database=BookManagement;server=XTZJ-20220423MW";//SQL Server链接字符串
            SqlConnection conn = new SqlConnection(strConn);
            SqlDataAdapter sda1 = new SqlDataAdapter(sql1, conn);
            SqlDataAdapter sda2 = new SqlDataAdapter(sql2, conn);
            SqlDataAdapter sda3 = new SqlDataAdapter(sql3, conn);
            DataTable dt1 = new DataTable();//dt是一个表类型。
            DataTable dt2 = new DataTable();//dt是一个表类型。
            DataTable dt3 = new DataTable();//dt是一个表类型。
            sda1.Fill(dt1);//把sda读取的数据填到dt里
            sda2.Fill(dt2);//把sda读取的数据填到dt里
            sda2.Fill(dt3);//把sda读取的数据填到dt里
            dataGridView6.DataSource = dt1;//把dt的内容绑定到Gridview1里显示
            dataGridView3.DataSource = dt2;//把dt的内容绑定到Gridview1里显示
            dataGridView3.DataSource = dt3;//把dt的内容绑定到Gridview1里显示


        }

        /// <summary>
        /// 计时器
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {

            this.statusCurrentTime.Text = "当前时间：" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
        }




        private void toolStripStatusLabel3_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }


    }
}
