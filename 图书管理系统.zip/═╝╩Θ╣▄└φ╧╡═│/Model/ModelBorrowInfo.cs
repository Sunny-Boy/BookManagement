﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class ModelBorrowInfo
    {
        public string book_name { get; set; }
        public string book_id { get; set; }
        public string user_name { get; set; }
        public string user_id { get; set; }
        public string time { get; set; }
        public string return_time { get; set; }
    }
}
