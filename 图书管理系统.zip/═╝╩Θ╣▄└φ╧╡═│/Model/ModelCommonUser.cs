﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class ModelCommonUser
    {
        public string id { get; set; }
        public string name { get; set; }
        public string gender { get; set; }
        public string phone { get; set; }
        public string QQ { get; set; }
        public string academy { get; set; }
        public string major { get; set; }
        public string note { get; set; }
        public string state { get; set; }

        public string password{ get; set; }
        public string registration_time { get; set; }
        public int borrow_book_num { get; set; }
        public string not_returned_book { get; set; }

    }
}
