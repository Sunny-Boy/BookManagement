﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class ModelBookTable
    {
        public string id { get; set; }
        public string name { get; set; }
        public string author { get; set; }
        public string price { get; set; }
        public string book_abstract { get; set; }
        public string press { get; set; }
        public string location { get; set; }
        public string time { get; set; }
        public string inventory { get; set; }
        public int borrow_num { get; set; }

    }
}
