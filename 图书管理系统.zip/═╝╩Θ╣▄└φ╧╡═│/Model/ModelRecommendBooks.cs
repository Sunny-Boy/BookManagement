﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class ModelRecommendBooks
    {
        public string book_name { get; set; }
        public string book_author { get; set; }
        public string link { get; set; }
        public string reason { get; set; }
        public string user_id { get; set; }
        public string user_academy { get; set; }
        public string purchases { get; set; }
        
    }
}
