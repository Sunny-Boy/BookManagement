﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using DAL;

namespace BLL
{
    public class BllLoginAPI
    {
        public ModelLogin login(string id, string password,string identity)
        {
            return new DalLoginServer().login(id, password,identity);
        }
    }
}
