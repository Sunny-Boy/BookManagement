﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using Model;

namespace BLL
{
    public class BllAdminUserOperationAPI
    {
        /// <summary>
        /// 添加管理员接口
        /// </summary>
        public int AddAdminUser(ModelAdminUserTable admin)
        {
            return new DalAdminUserOperation().AddAdminUser(admin);
        }
        
        /// <summary>
        /// 查询当前用户的全部个人信息
        /// </summary>
        public ModelAdminUserTable FindAdminUserInfo(string id)
        {
            return new DalAdminUserOperation().FindAdminUserInfo(id);
        }
        /// <summary>
        /// 修改信息
        /// </summary>
        public int ChangePersonalInfo(string key,string vlaue,string id)
        {
            return new DalAdminUserOperation().ChangePersonalInfo(key,vlaue, id);
        }

        /// <summary>
        /// 修改普通用的状态 锁定/正常
        /// </summary>
        public int ChangeCommonState(string id,string state)
        {
            return new DalAdminUserOperation().ChangeCommonStatus(id,state);
        }

        /// <summary>
        /// 删除当前的普通用户
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int DelCommonUser(string id)
        {
            return new DalAdminUserOperation().DelCommonUser(id);
        }

        /// <summary>
        /// 添加新书
        /// </summary>
        /// <param name="bookInfo"></param>
        /// <returns></returns>
        public int AddNewBook(ModelBookTable bookInfo)
        {
            return new DalAdminUserOperation().AddNewBook(bookInfo);
        }

        /// <summary>
        /// 查找在数据库中是否有相同书籍
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ModelBookTable FindBookTableInfo(string name)
        {
            return new DalAdminUserOperation().FindBookTableInfo(name);
        }


        /// <summary>
        /// 删除图书
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int DelBook(string id)
        {
            return new DalAdminUserOperation().DelBook(id);

        }

        /// <summary>
        /// 修改图书信息
        /// </summary>
        public int ModifyBookInfo(string key, string value, string name)
        {
            return new DalAdminUserOperation().ModifyBookInfo(key, value, name);
        }
    }
}
