﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using DAL;

namespace BLL
{
    public class BllCommonUserOperationAPI
    {
        public ModelCommonUser QueryState(string id)
        {
            return new DalCommonUserOperation().QueryState(id);
        }

        public ModelCommonUser QueryAllInfo(string id)
        {
            return new DalCommonUserOperation().QueryAllInfo(id);
        }

        public int UpdateInfo(string id,string key,string value)
        {
            return new DalCommonUserOperation().UpDateValue(id,key,value);

        }
        public int ChangePassword(string id,string newPassword)
        {
            return new DalCommonUserOperation().ChangePassword(id, newPassword);

        }


        /// <summary>
        /// 推荐图书
        /// </summary>
        /// <param name="recommend"></param>
        /// <returns></returns>
        public int IntroduceBookInfo(ModelRecommendBooks recommend)
        {
            return new DalCommonUserOperation().IntroduceBook(recommend);

        }
        /// <summary>
        /// 查找有没有重复书籍
        /// </summary>
        /// <param name="bookName"></param>
        /// <returns></returns>
        public ModelBookTable FindRepeatBook(string bookName)
        {
            return new DalCommonUserOperation().FindRepeatBook(bookName);
        }



        public ModelBookTable BorrowBook(string name)
        {
            return new DalCommonUserOperation().QueryBookInfo(name);
        }
        /// <summary>
        /// 借书操作
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>

        public int BorrowBookOp(ModelBorrowInfo info)
        {
            return new DalCommonUserOperation().BorrowBook(info);
        }

        public int UpdateBookInventory(ModelBookTable inventory)
        {
            return new DalCommonUserOperation().UpdateBookInventory(inventory);
        }
        //UpdateUserBorrowInfo(string id)
        public int UpdateUserBorrowInfo(string id)
        {
            return new DalCommonUserOperation().UpdateUserBorrowInfo(id);
        }

        /// <summary>
        /// 还书操作
        /// </summary>
        /// <param name="id">书本的id</param>
        /// <param name="bookname">书名</param>
        /// <returns></returns>
        public int UpdataBorrowInfo(string book_name,string user_name)
        {
            return new DalCommonUserOperation().UpdateBorrowBookInfo(book_name, user_name);
        }
        public int UpdataBookTableInvento(string book_id)
        {
            return new DalCommonUserOperation().UpdateBookTableInventory(book_id);
        }
    }
}
